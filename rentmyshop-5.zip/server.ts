import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '256kb' }));

// Security Headers Middleware
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

// In-Memory Sliding-Window Rate Limiter for Cost & Abuse Prevention
interface RateLimitBucket {
  timestamps: number[];
}
const rateLimitMap = new Map<string, RateLimitBucket>();
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 15; // Max 15 AI prompts per minute per IP

// Periodic cleanup of stale rate-limit buckets every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [ip, bucket] of rateLimitMap.entries()) {
    bucket.timestamps = bucket.timestamps.filter((t) => now - t < RATE_LIMIT_WINDOW_MS);
    if (bucket.timestamps.length === 0) {
      rateLimitMap.delete(ip);
    }
  }
}, 5 * 60 * 1000);

const rateLimiter = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const bucket = rateLimitMap.get(clientIp) || { timestamps: [] };

  bucket.timestamps = bucket.timestamps.filter((t) => now - t < RATE_LIMIT_WINDOW_MS);

  if (bucket.timestamps.length >= MAX_REQUESTS_PER_WINDOW) {
    const oldest = bucket.timestamps[0];
    const retryAfter = Math.ceil((RATE_LIMIT_WINDOW_MS - (now - oldest)) / 1000);
    res.setHeader('Retry-After', retryAfter.toString());
    return res.status(429).json({
      error: `Too many AI requests. Please wait ${retryAfter} seconds before asking again.`,
      retryAfter,
    });
  }

  bucket.timestamps.push(now);
  rateLimitMap.set(clientIp, bucket);
  next();
};

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Gemini AI Support endpoint with Rate Limiting & Input Validation
app.post('/api/support-chat', rateLimiter, async (req, res) => {
  try {
    const { messages, publicListings } = req.body;

    // Strict payload validation
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required and must not be empty.' });
    }

    if (messages.length > 20) {
      return res.status(400).json({ error: 'Conversation history exceeds maximum permitted length (20 messages).' });
    }

    // Validate and sanitize individual messages
    const sanitizedMessages: { role: string; content: string }[] = [];
    for (const m of messages) {
      if (!m || typeof m !== 'object') continue;
      const role = m.role === 'assistant' || m.role === 'model' ? 'model' : 'user';
      let content = typeof m.content === 'string' ? m.content.trim() : '';
      if (!content) continue;
      // Cap individual message length to prevent unbounded token amplification
      if (content.length > 1500) {
        content = content.slice(0, 1500);
      }
      sanitizedMessages.push({ role, content });
    }

    if (sanitizedMessages.length === 0) {
      return res.status(400).json({ error: 'No valid message content provided.' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({
        error: 'RentMyShop AI Support is temporarily offline. API key configuration missing.',
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        timeout: 20000,
        headers: { 'User-Agent': 'aistudio-build' },
      },
    });

    // Sanitize and bound platform context
    let listingsSummary = 'No listings currently available in marketplace session.';
    if (Array.isArray(publicListings) && publicListings.length > 0) {
      listingsSummary = publicListings
        .slice(0, 20)
        .filter((p: any) => p && typeof p === 'object')
        .map((p: any, index: number) => {
          const title = String(p.title || 'Commercial Property').slice(0, 80);
          const purpose = p.purpose === 'sale' ? 'sale' : 'rent';
          const category = String(p.category || 'Shop').slice(0, 30);
          const city = String(p.city || 'N/A').slice(0, 30);
          const price = Number(p.price || 0);
          const area = String(p.area || 'N/A').slice(0, 20);
          const isVerified = Boolean(p.isVerified);
          const details = p.description ? String(p.description).slice(0, 80) : '';
          return `[${index + 1}] Title: "${title}", Purpose: ${purpose}, Category: ${category}, City: ${city}, Price: PKR ${price.toLocaleString()}, Area: ${area}${isVerified ? ', Verified: Yes' : ''}${details ? `, Details: ${details}` : ''}`;
        })
        .join('\n');
    }

    const systemInstruction = `You are "RentMyShop", the dedicated AI customer-support assistant for RentMyShop — Pakistan's premier commercial property marketplace.

Core Identity & Tone:
- Agent Name: RentMyShop Support
- Tone: Friendly, concise, professional, courteous, and knowledgeable about commercial real estate in Pakistan.
- Primary Focus: Commercial shops, retail storefronts, executive corporate offices, warehouses, commercial plazas, kiosks, and plots for lease or sale.

Platform Capabilities to Guide Users On:
1. Finding Properties: Users can search by city (Karachi, Lahore, Islamabad, Rawalpindi, Peshawar, Faisalabad, Multan, Gujranwala, Quetta, Sialkot, etc.), filter by purpose (Rent vs Sale), category, price, and area using the Top Search Bar and Explore tab.
2. In-App Private Chat: Users can tap "Chat with Owner" on any property details screen to negotiate privately and securely in-app without sharing personal phone numbers. Long-pressing any chat allows permanently deleting it.
3. Listing Commercial Spaces: Users can list properties easily via the "Add" tab with photos, pricing, area details, and location.
4. Account & Verification: Sign-in/Sign-up supports email/password and Google Sign-in. Email verification is required before publishing or contacting owners for community safety.
5. Profile & Themes: Users can manage listings, favorites, and switch between Light Mode and Dark Mode in the Profile tab.

DATA GROUNDING & INTEGRITY (STRICT):
- You have real-time platform listings provided below.
- If asked about available shops, offices, or properties, ONLY reference properties that genuinely exist in the VERIFIED LISTINGS CONTEXT below.
- NEVER invent, hallucinate, or fabricate any property, owner name, phone number, location, or price.
- If no property matches the user's criteria (or if a requested city/category has no listings in context), clearly state that no matching listing is currently available on the marketplace, and encourage the user to check the Search / Explore page or list one.
- NEVER reveal internal database IDs, passwords, authentication tokens, private user records, or sensitive system details.
- Keep responses readable, using bullet points for multiple properties and clear formatting.

VERIFIED CURRENT LISTINGS:
${listingsSummary}
`;

    // Format chat history into contents
    const contents = sanitizedMessages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts: [{ text: m.content || '' }],
    }));

    // Candidate models to try with fallback
    const candidateModels = ['gemini-3.5-flash-lite', 'gemini-3.8-flash'];
    let lastError: any = null;
    let replyText = '';

    for (const model of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
            maxOutputTokens: 600,
          },
        });
        replyText = response.text || '';
        if (replyText) break;
      } catch (err: any) {
        lastError = err;
        console.warn(`[RentMyShop AI] Model ${model} failed, attempting fallback:`, err?.message || err);
      }
    }

    if (!replyText) {
      if (lastError?.status === 429 || lastError?.message?.includes('429') || lastError?.message?.includes('quota')) {
        return res.status(429).json({
          error: 'RentMyShop support is temporarily experiencing high request volume. Please wait a moment and try again.',
        });
      }
      throw lastError || new Error('No response generated');
    }

    return res.json({ reply: replyText });
  } catch (error: any) {
    console.error('[RentMyShop AI Support] Chat error:', error);
    return res.status(500).json({
      error: 'Unable to connect to RentMyShop AI at this moment. Please try again shortly.',
      details: error?.message,
    });
  }
});

// Setup Vite middleware in dev or static files in production
const isProduction = process.env.NODE_ENV === 'production';

if (!isProduction) {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (_req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`RentMyShop server running on http://0.0.0.0:${PORT}`);
});
