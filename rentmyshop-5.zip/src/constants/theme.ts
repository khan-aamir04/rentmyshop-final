/**
 * RentMyShop Design System Theme Constants
 * Approved Material 3 & Custom Identity
 */

export const THEME = {
  colors: {
    primary: '#FF6B00',
    primaryHover: '#E55F00',
    primaryLight: '#FFF5EE',
    primaryMuted: '#FFEDD5',
    background: '#FFFFFF',
    surface: '#F8F9FA',
    surfaceAlt: '#F1F5F9',
    card: '#FFFFFF',
    textMain: '#0F172A',
    textSecondary: '#64748B',
    textMuted: '#94A3B8',
    border: '#E2E8F0',
    borderHover: '#CBD5E1',
    success: '#10B981',
    successLight: '#ECFDF5',
    error: '#EF4444',
    errorLight: '#FEF2F2',
    warning: '#F59E0B',
    warningLight: '#FFFBEB',
  },
  radius: {
    card: '18px', // Approved card radius
    button: '14px', // Approved button radius
    input: '14px', // Approved input radius
    bottomSheet: '24px', // Approved bottom sheet radius
    dialog: '20px', // Approved dialog radius
    pill: '9999px',
  },
  spacing: {
    1: '4px',
    2: '8px',
    3: '12px',
    4: '16px',
    5: '20px',
    6: '24px',
    8: '32px',
    10: '40px',
    12: '48px',
  },
};
