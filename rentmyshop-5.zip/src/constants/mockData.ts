import { CategoryModel } from '../types';

export const INITIAL_CATEGORIES: CategoryModel[] = [
  { id: 'cat-1', name: 'Shops', iconName: 'Store', isActive: true, ordering: 1, count: 0 },
  { id: 'cat-2', name: 'Offices', iconName: 'Building2', isActive: true, ordering: 2, count: 0 },
  { id: 'cat-3', name: 'Warehouses', iconName: 'Warehouse', isActive: true, ordering: 3, count: 0 },
  { id: 'cat-4', name: 'Commercial Plaza', iconName: 'Building', isActive: true, ordering: 4, count: 0 },
  { id: 'cat-5', name: 'Kiosk', iconName: 'ShoppingBag', isActive: true, ordering: 5, count: 0 },
  { id: 'cat-6', name: 'Commercial Plot', iconName: 'LandPlot', isActive: true, ordering: 6, count: 0 },
];
