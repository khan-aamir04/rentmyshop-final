/**
 * RentMyShop - Main Application Entry Point
 * Comprehensive commercial property marketplace with modular React Context architecture.
 */
import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { PropertyProvider, useProperties } from './context/PropertyContext';
import { ChatProvider, useChat } from './context/ChatContext';
import { NotificationProvider, useNotifications } from './context/NotificationContext';
import { ThemeProvider } from './context/ThemeContext';
import { PropertyModel, PropertyCategory } from './types';

// Screens
import { SplashScreen } from './screens/SplashScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';
import { LoginScreen } from './screens/auth/LoginScreen';
import { SignupScreen } from './screens/auth/SignupScreen';
import { ForgotPasswordScreen } from './screens/auth/ForgotPasswordScreen';
import { EmailVerificationScreen } from './screens/auth/EmailVerificationScreen';
import { ProfileSetupScreen } from './screens/auth/ProfileSetupScreen';
import { HomeScreen } from './screens/HomeScreen';
import { ExploreScreen } from './screens/ExploreScreen';
import { PropertyDetailsScreen } from './screens/PropertyDetailsScreen';
import { AddListingScreen } from './screens/AddListingScreen';
import { MyListingsScreen } from './screens/MyListingsScreen';
import { FavoritesScreen } from './screens/FavoritesScreen';
import { ChatListScreen } from './screens/ChatListScreen';
import { ChatDetailScreen } from './screens/ChatDetailScreen';
import { NotificationsScreen } from './screens/NotificationsScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { AdminDashboardScreen } from './screens/admin/AdminDashboardScreen';

// Navigation & Layout Components
import { Header } from './components/common/Header';
import { BottomNav, NavTab } from './components/common/BottomNav';
import { SupportChatWidget } from './components/common/SupportChatWidget';

type AppView = 
  | 'home'
  | 'explore'
  | 'add'
  | 'my-listings'
  | 'favorites'
  | 'chats'
  | 'chat-detail'
  | 'notifications'
  | 'profile'
  | 'property-details'
  | 'admin';

type AuthView = 'login' | 'signup' | 'forgot-password';

const MainAppContent: React.FC = () => {
  const { currentUser, isAuthInitializing } = useAuth();
  const { properties, setSelectedCategory } = useProperties();
  const { totalUnreadCount } = useChat();
  const { unreadCount: notifUnreadCount } = useNotifications();

  // App Lifecycle States
  const [showSplash, setShowSplash] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [authView, setAuthView] = useState<AuthView>('login');

  // Navigation State
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [viewHistory, setViewHistory] = useState<AppView[]>(['home']);
  const [selectedProperty, setSelectedProperty] = useState<PropertyModel | null>(null);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);

  // Check onboarding on initial load
  useEffect(() => {
    const onboardingDone = localStorage.getItem('rentmyshop_onboarding_completed');
    if (!onboardingDone) {
      setShowOnboarding(true);
    }
  }, []);

  const completeOnboarding = () => {
    localStorage.setItem('rentmyshop_onboarding_completed', 'true');
    setShowOnboarding(false);
  };

  // Navigation Helper
  const navigateTo = (view: AppView) => {
    setViewHistory((prev) => [...prev, view]);
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateBack = () => {
    if (viewHistory.length > 1) {
      const newHistory = [...viewHistory];
      newHistory.pop();
      const previous = newHistory[newHistory.length - 1];
      setViewHistory(newHistory);
      setCurrentView(previous);
    } else {
      setCurrentView('home');
      setViewHistory(['home']);
    }
  };

  // Handlers for cross-screen interactions
  const handleSelectProperty = (property: PropertyModel) => {
    setSelectedProperty(property);
    navigateTo('property-details');
  };

  const handleOpenPropertyById = (propertyId: string) => {
    const found = properties.find((p) => p.id === propertyId);
    if (found) {
      handleSelectProperty(found);
    }
  };

  const handleOpenChat = (conversationId: string) => {
    setActiveConversationId(conversationId);
    navigateTo('chat-detail');
  };

  const handleExploreCategory = (cat?: PropertyCategory) => {
    if (cat) {
      setSelectedCategory(cat);
    }
    navigateTo('explore');
  };

  // 1. Splash Screen
  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  // 2. Onboarding Flow (4 Steps)
  if (showOnboarding) {
    return <OnboardingScreen onComplete={completeOnboarding} />;
  }

  // 3. Waiting for Firebase Auth Initial Resolution
  if (isAuthInitializing) {
    return <SplashScreen onFinish={() => {}} />;
  }

  // 4. Auth Flow (if not authenticated)
  if (!currentUser) {
    if (authView === 'signup') {
      return <SignupScreen onNavigateToLogin={() => setAuthView('login')} />;
    }
    if (authView === 'forgot-password') {
      return <ForgotPasswordScreen onBackToLogin={() => setAuthView('login')} />;
    }
    return (
      <LoginScreen
        onNavigateToSignup={() => setAuthView('signup')}
        onNavigateToForgotPassword={() => setAuthView('forgot-password')}
      />
    );
  }

  // 5. Email Verification Enforcement (unverified accounts cannot access main app)
  if (!currentUser.emailVerified) {
    return (
      <EmailVerificationScreen
        onVerified={() => {
          // Status updated in AuthContext; re-rendering will pass this guard
        }}
      />
    );
  }

  // Determine current active BottomNav tab
  const getActiveTab = (): NavTab => {
    if (currentView === 'home') return 'home';
    if (currentView === 'explore') return 'explore';
    if (currentView === 'add') return 'add_listing';
    if (currentView === 'chats' || currentView === 'chat-detail') return 'chats';
    if (currentView === 'profile' || currentView === 'my-listings' || currentView === 'favorites' || currentView === 'admin') {
      return 'profile';
    }
    return 'home';
  };

  const showBottomNav = currentView !== 'property-details' && currentView !== 'chat-detail' && currentView !== 'add';

  // Determine header configuration
  const isNested = currentView !== 'home';
  const getHeaderTitle = () => {
    switch (currentView) {
      case 'explore':
        return 'Explore Commercial';
      case 'chats':
        return 'Commercial Messages';
      case 'profile':
        return 'Commercial Profile';
      case 'favorites':
        return 'Saved Properties';
      case 'my-listings':
        return 'My Listings';
      case 'notifications':
        return 'Notifications';
      case 'admin':
        return 'Admin Moderation';
      default:
        return undefined;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-slate-900 flex flex-col justify-between select-none">
      {/* Universal Top Header (hidden on custom detail/chat headers) */}
      {currentView !== 'property-details' && currentView !== 'chat-detail' && currentView !== 'add' && (
        <Header
          title={getHeaderTitle()}
          isNested={isNested}
          onBack={navigateBack}
          onOpenNotifications={() => navigateTo('notifications')}
          onOpenProfile={() => navigateTo('profile')}
          notificationCount={notifUnreadCount}
        />
      )}

      {/* Main Screen Views */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomeScreen
            onSelectProperty={handleSelectProperty}
            onNavigateToExplore={handleExploreCategory}
            onNavigateToAdd={() => navigateTo('add')}
          />
        )}
        {currentView === 'explore' && (
          <ExploreScreen
            onSelectProperty={handleSelectProperty}
            onNavigateToAdd={() => navigateTo('add')}
          />
        )}
        {currentView === 'add' && (
          <AddListingScreen
            onCancel={navigateBack}
            onSuccess={(newProp) => {
              setSelectedProperty(newProp);
              navigateTo('property-details');
            }}
          />
        )}
        {currentView === 'property-details' && selectedProperty && (
          <PropertyDetailsScreen
            property={selectedProperty}
            onBack={navigateBack}
            onOpenChat={handleOpenChat}
          />
        )}
        {currentView === 'my-listings' && (
          <MyListingsScreen
            onSelectProperty={handleSelectProperty}
            onNavigateToAddListing={() => navigateTo('add')}
          />
        )}
        {currentView === 'favorites' && (
          <FavoritesScreen
            onSelectProperty={handleSelectProperty}
            onNavigateToExplore={() => navigateTo('explore')}
          />
        )}
        {currentView === 'chats' && (
          <ChatListScreen
            onOpenConversation={handleOpenChat}
            onNavigateToExplore={() => navigateTo('explore')}
          />
        )}
        {currentView === 'chat-detail' && activeConversationId && (
          <ChatDetailScreen
            conversationId={activeConversationId}
            onBack={navigateBack}
            onViewProperty={handleOpenPropertyById}
          />
        )}
        {currentView === 'notifications' && (
          <NotificationsScreen
            onSelectProperty={handleOpenPropertyById}
            onOpenChat={handleOpenChat}
          />
        )}
        {currentView === 'profile' && (
          <ProfileScreen
            onNavigateToMyListings={() => navigateTo('my-listings')}
            onNavigateToFavorites={() => navigateTo('favorites')}
            onNavigateToAdmin={() => navigateTo('admin')}
          />
        )}
        {currentView === 'admin' && (
          <AdminDashboardScreen
            onBack={navigateBack}
          />
        )}
      </main>

      {/* Fixed Bottom Navigation */}
      {showBottomNav && (
        <BottomNav
          activeTab={getActiveTab()}
          onTabChange={(tab) => {
            if (tab === 'home') navigateTo('home');
            else if (tab === 'explore') navigateTo('explore');
            else if (tab === 'add' || tab === 'add_listing') navigateTo('add');
            else if (tab === 'chats') navigateTo('chats');
            else if (tab === 'profile') navigateTo('profile');
          }}
          unreadChatsCount={totalUnreadCount}
        />
      )}

      {/* RentMyShop AI Customer Support Widget */}
      <SupportChatWidget />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <PropertyProvider>
          <ChatProvider>
            <NotificationProvider>
              <MainAppContent />
            </NotificationProvider>
          </ChatProvider>
        </PropertyProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
