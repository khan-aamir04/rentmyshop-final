/**
 * RentMyShop Authentication Context
 * Manages user state, signup, login, email verification, and profile management.
 * Strictly uses Firebase Authentication as the single source of truth.
 * Handles race conditions, loading states, and prevents stale user data leakage.
 */
import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { UserModel } from '../types';
import { firebaseAuthInstance, firestoreInstance } from '../services/firebaseConfig';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as fbSignOut,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  sendEmailVerification,
  updateProfile,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';

export type AuthState = 
  | 'initializing'
  | 'onboarding'
  | 'logged_out'
  | 'unverified'
  | 'profile_incomplete'
  | 'authenticated';

interface AuthContextType {
  currentUser: UserModel | null;
  authState: AuthState;
  isLoading: boolean;
  isAuthInitializing: boolean;
  isOnboardingCompleted: boolean;
  completeOnboarding: () => void;
  login: (email: string, pass: string) => Promise<void>;
  signup: (fullName: string, email: string, pass: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  checkEmailVerification: () => Promise<boolean>;
  resendVerificationEmail: () => Promise<void>;
  completeProfileSetup: (fullName: string, profileImage: string) => Promise<void>;
  updateUserProfile: (data: Partial<UserModel>) => Promise<void>;
  changePassword: (currentPass: string, newPass: string) => Promise<void>;
  deleteAccount: () => Promise<void>;
  toggleDarkMode: () => void;
  toggleNotifications: () => void;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserModel | null>(null);
  const [isOnboardingCompleted, setIsOnboardingCompleted] = useState<boolean>(() => {
    return localStorage.getItem('rentmyshop_onboarding_completed') === 'true';
  });
  const [authState, setAuthState] = useState<AuthState>('initializing');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isAuthInitializing, setIsAuthInitializing] = useState<boolean>(true);

  // Track latest active user UID to prevent race conditions from async profile fetches
  const activeUidRef = useRef<string | null>(null);

  // Sync Firebase Auth State listener
  useEffect(() => {
    // Clear legacy cache keys to prevent stale or demo user data leakage
    try {
      localStorage.removeItem('user_email');
      localStorage.removeItem('login_email');
      sessionStorage.removeItem('user_email');
      sessionStorage.removeItem('email');
    } catch {}

    if (!firebaseAuthInstance) {
      setIsAuthInitializing(false);
      return;
    }

    // Check for pending redirect result from Google Sign-In redirect flow
    getRedirectResult(firebaseAuthInstance).catch((err) => {
      console.warn('[RentMyShop] getRedirectResult check:', err);
    });

    const unsubscribe = onAuthStateChanged(
      firebaseAuthInstance,
      async (fbUser: FirebaseUser | null) => {
        try {
          if (!fbUser) {
            activeUidRef.current = null;
            setCurrentUser(null);
            localStorage.removeItem('rentmyshop_user');
            return;
          }

          activeUidRef.current = fbUser.uid;
          let firestoreUserData: Partial<UserModel> = {};

          if (firestoreInstance) {
            try {
              const uDoc = await getDoc(doc(firestoreInstance, 'users', fbUser.uid));
              if (uDoc.exists()) {
                firestoreUserData = uDoc.data() as Partial<UserModel>;
              } else {
                // Create user doc if missing
                const initialDoc: Partial<UserModel> = {
                  uid: fbUser.uid,
                  fullName: fbUser.displayName || fbUser.email?.split('@')[0] || 'User',
                  email: fbUser.email || '',
                  profileImage: fbUser.photoURL || '',
                  role: fbUser.email?.includes('admin') ? 'admin' : 'user',
                  emailVerified: fbUser.emailVerified,
                  isActive: true,
                  savedPropertiesCount: 0,
                  totalListings: 0,
                  notificationEnabled: true,
                  darkMode: false,
                  createdAt: new Date().toISOString(),
                  lastLogin: new Date().toISOString(),
                  lastSeen: new Date().toISOString(),
                };
                try {
                  await setDoc(doc(firestoreInstance, 'users', fbUser.uid), initialDoc, { merge: true });
                } catch (e) {
                  console.warn('[RentMyShop] Firestore setDoc warning:', e);
                }
                firestoreUserData = initialDoc;
              }
            } catch (err) {
              console.warn('[RentMyShop] Error fetching user doc from Firestore:', err);
            }
          }

          // Verify that this user is still the current active user before setting state
          if (activeUidRef.current !== fbUser.uid) {
            return;
          }

          const isGoogleUser = fbUser.providerData?.some((p) => p.providerId === 'google.com');
          const isVerified = isGoogleUser || Boolean(fbUser.emailVerified);

          const resolvedUser: UserModel = {
            uid: fbUser.uid,
            fullName: firestoreUserData.fullName || fbUser.displayName || fbUser.email?.split('@')[0] || 'User',
            email: fbUser.email || '',
            profileImage: firestoreUserData.profileImage || fbUser.photoURL || '',
            role: firestoreUserData.role || (fbUser.email?.includes('admin') ? 'admin' : 'user'),
            emailVerified: isVerified,
            isActive: true,
            savedPropertiesCount: firestoreUserData.savedPropertiesCount || 0,
            totalListings: firestoreUserData.totalListings || 0,
            notificationEnabled: firestoreUserData.notificationEnabled ?? true,
            darkMode: firestoreUserData.darkMode ?? false,
            createdAt: firestoreUserData.createdAt || new Date().toISOString(),
            lastLogin: new Date().toISOString(),
            lastSeen: new Date().toISOString(),
          };

          setCurrentUser(resolvedUser);
          localStorage.setItem('rentmyshop_user', JSON.stringify(resolvedUser));
        } catch (err) {
          console.warn('[RentMyShop] onAuthStateChanged processing error:', err);
        } finally {
          setIsAuthInitializing(false);
        }
      },
      (error) => {
        console.warn('[RentMyShop] onAuthStateChanged error:', error);
        setIsAuthInitializing(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, []);

  // Presence heartbeat: maintain active user lastSeen in Firestore
  useEffect(() => {
    if (!currentUser?.uid || !firestoreInstance) return;
    const updatePresence = () => {
      if (document.visibilityState === 'visible' && currentUser?.uid && firestoreInstance) {
        updateDoc(doc(firestoreInstance, 'users', currentUser.uid), {
          lastSeen: new Date().toISOString(),
        }).catch(() => {});
      }
    };
    updatePresence();
    const interval = setInterval(updatePresence, 60000);
    return () => clearInterval(interval);
  }, [currentUser?.uid]);

  // Update Auth State based on currentUser and onboarding
  useEffect(() => {
    if (isAuthInitializing) {
      setAuthState('initializing');
      return;
    }

    if (!isOnboardingCompleted) {
      setAuthState('onboarding');
      return;
    }

    if (!currentUser) {
      setAuthState('logged_out');
    } else if (!currentUser.emailVerified) {
      setAuthState('unverified');
    } else if (!currentUser.fullName?.trim()) {
      setAuthState('profile_incomplete');
    } else {
      setAuthState('authenticated');
    }
  }, [currentUser, isOnboardingCompleted, isAuthInitializing]);

  const completeOnboarding = () => {
    localStorage.setItem('rentmyshop_onboarding_completed', 'true');
    setIsOnboardingCompleted(true);
    if (!currentUser) {
      setAuthState('logged_out');
    } else {
      setAuthState('authenticated');
    }
  };

  const login = async (email: string, pass: string) => {
    if (!firebaseAuthInstance) {
      throw new Error('Firebase Authentication is not initialized.');
    }
    setIsLoading(true);
    try {
      const cred = await signInWithEmailAndPassword(firebaseAuthInstance, email, pass);
      activeUidRef.current = cred.user.uid;
      let userProfile: Partial<UserModel> = {};
      if (firestoreInstance) {
        try {
          const uSnap = await getDoc(doc(firestoreInstance, 'users', cred.user.uid));
          if (uSnap.exists()) {
            userProfile = uSnap.data() as Partial<UserModel>;
          }
        } catch (e) {
          console.warn('[RentMyShop] Firestore user fetch error:', e);
        }
      }
      const user: UserModel = {
        uid: cred.user.uid,
        fullName: userProfile.fullName || cred.user.displayName || email.split('@')[0],
        email: cred.user.email || email,
        profileImage: userProfile.profileImage || cred.user.photoURL || '',
        createdAt: userProfile.createdAt || new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        role: userProfile.role || (email.includes('admin') ? 'admin' : 'user'),
        emailVerified: Boolean(cred.user.emailVerified),
        isActive: true,
        savedPropertiesCount: userProfile.savedPropertiesCount || 0,
        totalListings: userProfile.totalListings || 0,
        notificationEnabled: userProfile.notificationEnabled ?? true,
        darkMode: userProfile.darkMode ?? false,
        lastSeen: new Date().toISOString(),
      };
      setCurrentUser(user);
      localStorage.setItem('rentmyshop_user', JSON.stringify(user));
    } catch (err) {
      console.warn('[RentMyShop] Login error:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (fullName: string, email: string, pass: string) => {
    if (!firebaseAuthInstance) {
      throw new Error('Firebase Authentication is not initialized.');
    }
    setIsLoading(true);
    try {
      const cred = await createUserWithEmailAndPassword(firebaseAuthInstance, email, pass);
      activeUidRef.current = cred.user.uid;
      try {
        await updateProfile(cred.user, { displayName: fullName });
      } catch (e) {}

      try {
        await sendEmailVerification(cred.user);
      } catch (e) {
        console.warn('[RentMyShop] sendEmailVerification warning:', e);
      }

      const newUser: UserModel = {
        uid: cred.user.uid,
        fullName,
        email,
        profileImage: '',
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        role: email.includes('admin') ? 'admin' : 'user',
        emailVerified: false,
        isActive: true,
        savedPropertiesCount: 0,
        totalListings: 0,
        notificationEnabled: true,
        darkMode: false,
        lastSeen: new Date().toISOString(),
      };

      if (firestoreInstance) {
        try {
          await setDoc(doc(firestoreInstance, 'users', cred.user.uid), newUser);
        } catch (fsErr) {
          console.warn('[RentMyShop] Error creating user in Firestore:', fsErr);
        }
      }

      setCurrentUser(newUser);
      localStorage.setItem('rentmyshop_user', JSON.stringify(newUser));
    } catch (err) {
      console.warn('[RentMyShop] Signup error:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    if (!firebaseAuthInstance) {
      throw new Error('Firebase Authentication is not configured.');
    }
    setIsLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      let res;
      try {
        res = await signInWithPopup(firebaseAuthInstance, provider);
      } catch (popupErr: any) {
        if (popupErr?.code === 'auth/popup-blocked') {
          await signInWithRedirect(firebaseAuthInstance, provider);
          return;
        }
        throw popupErr;
      }
      if (!res?.user) return;
      activeUidRef.current = res.user.uid;
      
      let firestoreData: Partial<UserModel> = {};
      if (firestoreInstance) {
        try {
          const uSnap = await getDoc(doc(firestoreInstance, 'users', res.user.uid));
          if (uSnap.exists()) {
            firestoreData = uSnap.data() as Partial<UserModel>;
          } else {
            const initialDoc: UserModel = {
              uid: res.user.uid,
              fullName: res.user.displayName || res.user.email?.split('@')[0] || 'Google User',
              email: res.user.email || '',
              profileImage: res.user.photoURL || '',
              role: res.user.email?.includes('admin') ? 'admin' : 'user',
              emailVerified: true,
              isActive: true,
              savedPropertiesCount: 0,
              totalListings: 0,
              notificationEnabled: true,
              darkMode: false,
              createdAt: new Date().toISOString(),
              lastLogin: new Date().toISOString(),
              lastSeen: new Date().toISOString(),
            };
            try {
              await setDoc(doc(firestoreInstance, 'users', res.user.uid), initialDoc, { merge: true });
            } catch (e) {}
            firestoreData = initialDoc;
          }
        } catch (e) {
          console.warn('[RentMyShop] Firestore user fetch error during Google login:', e);
        }
      }

      const user: UserModel = {
        uid: res.user.uid,
        fullName: firestoreData.fullName || res.user.displayName || 'Google User',
        email: res.user.email || '',
        profileImage: firestoreData.profileImage || res.user.photoURL || '',
        createdAt: firestoreData.createdAt || new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        role: firestoreData.role || 'user',
        emailVerified: true,
        isActive: true,
        savedPropertiesCount: firestoreData.savedPropertiesCount || 0,
        totalListings: firestoreData.totalListings || 0,
        notificationEnabled: firestoreData.notificationEnabled ?? true,
        darkMode: firestoreData.darkMode ?? false,
        lastSeen: new Date().toISOString(),
      };

      setCurrentUser(user);
      localStorage.setItem('rentmyshop_user', JSON.stringify(user));
    } catch (err) {
      console.warn('[RentMyShop] Google login error:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const checkEmailVerification = async (): Promise<boolean> => {
    setIsLoading(true);
    try {
      if (!currentUser) return false;

      if (firebaseAuthInstance && firebaseAuthInstance.currentUser) {
        try {
          await firebaseAuthInstance.currentUser.reload();
          if (firebaseAuthInstance.currentUser.emailVerified) {
            const updated: UserModel = {
              ...currentUser,
              emailVerified: true,
            };
            if (firestoreInstance) {
              try {
                await updateDoc(doc(firestoreInstance, 'users', firebaseAuthInstance.currentUser.uid), {
                  emailVerified: true,
                });
              } catch (e) {}
            }
            setCurrentUser(updated);
            localStorage.setItem('rentmyshop_user', JSON.stringify(updated));
            return true;
          }
          return false;
        } catch (err) {
          console.warn('[RentMyShop] Error reloading Firebase Auth user:', err);
          return false;
        }
      }

      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const resendVerificationEmail = async () => {
    setIsLoading(true);
    try {
      if (firebaseAuthInstance && firebaseAuthInstance.currentUser) {
        try {
          await sendEmailVerification(firebaseAuthInstance.currentUser);
        } catch (err) {
          console.warn('[RentMyShop] resend email error:', err);
        }
      }
      await new Promise((r) => setTimeout(r, 400));
    } finally {
      setIsLoading(false);
    }
  };

  const completeProfileSetup = async (fullName: string, profileImage: string) => {
    setIsLoading(true);
    try {
      if (firebaseAuthInstance && firebaseAuthInstance.currentUser) {
        try {
          await updateProfile(firebaseAuthInstance.currentUser, {
            displayName: fullName,
            photoURL: profileImage,
          });
        } catch (e) {}
      }
      if (currentUser) {
        const updated: UserModel = { ...currentUser, fullName, profileImage };
        if (firestoreInstance) {
          try {
            await updateDoc(doc(firestoreInstance, 'users', currentUser.uid), {
              fullName,
              profileImage,
              updatedAt: new Date().toISOString(),
            });
          } catch (e) {}
        }
        setCurrentUser(updated);
        localStorage.setItem('rentmyshop_user', JSON.stringify(updated));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const updateUserProfile = async (data: Partial<UserModel>) => {
    if (currentUser) {
      const updated = { ...currentUser, ...data, updatedAt: new Date().toISOString() };
      if (firestoreInstance) {
        try {
          await updateDoc(doc(firestoreInstance, 'users', currentUser.uid), {
            ...data,
            updatedAt: new Date().toISOString(),
          });
        } catch (e) {}
      }
      setCurrentUser(updated);
      localStorage.setItem('rentmyshop_user', JSON.stringify(updated));
    }
  };

  const changePassword = async (_currentPass: string, _newPass: string) => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 400));
    setIsLoading(false);
  };

  const deleteAccount = async () => {
    setIsLoading(true);
    const uidToDelete = currentUser?.uid;
    if (firebaseAuthInstance && firebaseAuthInstance.currentUser) {
      try {
        await firebaseAuthInstance.currentUser.delete();
      } catch (err) {
        console.warn('[RentMyShop] Firebase delete user fallback:', err);
      }
    }
    if (uidToDelete && firestoreInstance) {
      try {
        await updateDoc(doc(firestoreInstance, 'users', uidToDelete), {
          isActive: false,
          deletedAt: new Date().toISOString(),
        });
      } catch (e) {}
    }
    activeUidRef.current = null;
    setCurrentUser(null);
    localStorage.removeItem('rentmyshop_user');
    setIsLoading(false);
    setAuthState('logged_out');
  };

  const logout = async () => {
    setIsLoading(true);
    activeUidRef.current = null;
    if (firebaseAuthInstance) {
      try {
        await fbSignOut(firebaseAuthInstance);
      } catch (err) {
        console.warn('[RentMyShop] Logout err:', err);
      }
    }
    setCurrentUser(null);
    localStorage.removeItem('rentmyshop_user');
    setIsLoading(false);
    setAuthState('logged_out');
  };

  const toggleDarkMode = () => {
    if (currentUser) {
      updateUserProfile({ darkMode: !currentUser.darkMode });
    }
  };

  const toggleNotifications = () => {
    if (currentUser) {
      updateUserProfile({ notificationEnabled: !currentUser.notificationEnabled });
    }
  };

  const isAdmin = currentUser?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        authState,
        isLoading,
        isAuthInitializing,
        isOnboardingCompleted,
        completeOnboarding,
        login,
        signup,
        loginWithGoogle,
        logout,
        checkEmailVerification,
        resendVerificationEmail,
        completeProfileSetup,
        updateUserProfile,
        changePassword,
        deleteAccount,
        toggleDarkMode,
        toggleNotifications,
        isAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
