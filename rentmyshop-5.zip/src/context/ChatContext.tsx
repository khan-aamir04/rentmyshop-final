/**
 * RentMyShop In-App Real-Time Chat Context
 * Manages conversations, message streams, seen receipts, and unread counts.
 * Strictly scopes conversations and messages to the authenticated user ID.
 */
import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { ConversationModel, MessageModel, PropertyModel } from '../types';
import { useAuth } from './AuthContext';
import { firestoreInstance } from '../services/firebaseConfig';
import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  getDoc, 
  query, 
  where, 
  onSnapshot 
} from 'firebase/firestore';

interface ChatContextType {
  conversations: ConversationModel[];
  activeConversation: ConversationModel | null;
  activeMessages: MessageModel[];
  isTyping: boolean;
  totalUnreadCount: number;
  openOrCreateConversation: (property: PropertyModel) => string;
  selectConversation: (id: string) => void;
  sendMessage: (conversationId: string, text: string, directReceiverId?: string) => Promise<void>;
  markAsSeen: (conversationId: string) => void;
  deleteMessage: (messageId: string) => void;
  deleteConversation: (conversationId: string) => Promise<void>;
  getMessagesForConversation: (conversationId: string) => MessageModel[];
  getDraftMessage: (conversationId: string) => string;
  clearDraftMessage: (conversationId: string) => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();

  const [conversations, setConversations] = useState<ConversationModel[]>([]);
  const [messagesMap, setMessagesMap] = useState<Record<string, MessageModel[]>>({});
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [isTyping, _setIsTyping] = useState<boolean>(false);
  const draftsRef = useRef<Record<string, string>>({});

  // Sync cache and state when currentUser changes
  useEffect(() => {
    if (!currentUser) {
      setConversations([]);
      setMessagesMap({});
      setActiveConversationId(null);
      return;
    }

    const currentUid = currentUser.uid;
    let deletedSet = new Set<string>();
    try {
      const deletedList: string[] = JSON.parse(
        localStorage.getItem(`rentmyshop_deleted_convs_${currentUid}`) || '[]'
      );
      deletedSet = new Set(deletedList);
    } catch {}

    const savedConvs = localStorage.getItem(`rentmyshop_convs_${currentUid}`);
    if (savedConvs) {
      try {
        const parsed = JSON.parse(savedConvs);
        const filtered = Array.isArray(parsed)
          ? parsed.filter(
              (c: any) =>
                !deletedSet.has(c.id) &&
                !(Array.isArray(c.deletedBy) && c.deletedBy.includes(currentUid))
            )
          : [];
        setConversations(filtered);
      } catch {}
    }

    const savedMsgs = localStorage.getItem(`rentmyshop_msgs_${currentUid}`);
    if (savedMsgs) {
      try {
        const parsedMsgs = JSON.parse(savedMsgs);
        if (parsedMsgs && typeof parsedMsgs === 'object') {
          deletedSet.forEach((delId) => {
            delete parsedMsgs[delId];
          });
        }
        setMessagesMap(parsedMsgs);
      } catch {}
    }
  }, [currentUser?.uid]);

  // 1. Real-time Firestore Sync for Conversations
  useEffect(() => {
    if (!currentUser || !firestoreInstance) {
      return;
    }

    const currentUid = currentUser.uid;
    const q = query(
      collection(firestoreInstance, 'conversations'),
      where('participants', 'array-contains', currentUid)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        let deletedSet = new Set<string>();
        try {
          const deletedList: string[] = JSON.parse(
            localStorage.getItem(`rentmyshop_deleted_convs_${currentUid}`) || '[]'
          );
          deletedSet = new Set(deletedList);
        } catch {}

        const liveConvs: ConversationModel[] = [];
        snapshot.forEach((d) => {
          const data = d.data();
          if (deletedSet.has(d.id)) return;
          if (Array.isArray(data?.deletedBy) && data.deletedBy.includes(currentUid)) {
            return;
          }
          liveConvs.push({ id: d.id, ...data } as ConversationModel);
        });
        setConversations(liveConvs);
        localStorage.setItem(`rentmyshop_convs_${currentUid}`, JSON.stringify(liveConvs));
      },
      (err) => {
        console.warn('[RentMyShop] Firestore conversations listener error:', err);
      }
    );

    return () => unsubscribe();
  }, [currentUser?.uid]);

  // 2. Real-time Firestore Sync for Messages in Active Conversation
  useEffect(() => {
    if (!activeConversationId || !firestoreInstance || !currentUser) return;

    const currentUid = currentUser.uid;

    const parseEpoch = (m: any): number => {
      if (!m) return 0;
      if (m.createdAt) {
        if (typeof m.createdAt === 'string') {
          const t = new Date(m.createdAt).getTime();
          if (!isNaN(t) && t > 0) return t;
        } else if (typeof m.createdAt?.toMillis === 'function') {
          return m.createdAt.toMillis();
        } else if (typeof m.createdAt?.toDate === 'function') {
          return m.createdAt.toDate().getTime();
        } else if (typeof m.createdAt === 'number') {
          return m.createdAt;
        }
      }
      if (typeof m.id === 'string' && m.id.startsWith('msg_')) {
        const parts = m.id.split('_');
        const num = Number(parts[1]);
        if (!isNaN(num) && num > 1000000) return num;
      }
      return 0;
    };

    const processSnapshot = (docsList: any[]) => {
      const liveMsgsMap = new Map<string, MessageModel>();
      docsList.forEach((d) => {
        const data = typeof d.data === 'function' ? d.data() : d;
        const textContent = data.message || data.text || '';
        const msgId = d.id || data.id;
        if (!msgId) return;
        liveMsgsMap.set(msgId, {
          id: msgId,
          conversationId: data.conversationId || activeConversationId,
          senderId: data.senderId || '',
          receiverId: data.receiverId || '',
          message: textContent,
          text: textContent,
          messageType: data.messageType || 'text',
          timestamp: data.timestamp || (data.createdAt ? new Date(data.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Just now'),
          createdAt: typeof data.createdAt === 'string' ? data.createdAt : new Date().toISOString(),
          seen: data.seen ?? data.isSeen ?? false,
          deleted: Boolean(data.deleted),
        });
      });

      const liveMsgs = Array.from(liveMsgsMap.values());
      liveMsgs.sort((a, b) => {
        const timeA = parseEpoch(a);
        const timeB = parseEpoch(b);
        if (timeA && timeB && timeA !== timeB) return timeA - timeB;
        return (a.id || '') > (b.id || '') ? 1 : -1;
      });

      setMessagesMap((prev) => {
        const next = { ...prev, [activeConversationId]: liveMsgs };
        localStorage.setItem(`rentmyshop_msgs_${currentUid}`, JSON.stringify(next));
        return next;
      });
    };

    let isCancelled = false;
    let unsubs: Array<() => void> = [];

    let participantDocs: any[] = [];
    let receiverDocs: any[] = [];
    let senderDocs: any[] = [];

    const updateAll = () => {
      if (isCancelled) return;
      processSnapshot([...participantDocs, ...receiverDocs, ...senderDocs]);
    };

    // 1. Primary participant-scoped query (complies strictly with Firestore participant security rules)
    try {
      const qPart = query(
        collection(firestoreInstance, 'messages'),
        where('conversationId', '==', activeConversationId),
        where('participants', 'array-contains', currentUid)
      );
      const unsubPart = onSnapshot(
        qPart,
        (snap) => {
          participantDocs = snap.docs;
          updateAll();
        },
        (err) => {
          console.warn('[RentMyShop] Messages participants listener warning:', err?.message || err);
        }
      );
      unsubs.push(unsubPart);
    } catch (e) {
      console.warn('[RentMyShop] Error setting up participant query:', e);
    }

    // 2. Supplementary queries for backwards compatibility with legacy messages lacking 'participants' field
    try {
      const qRecv = query(
        collection(firestoreInstance, 'messages'),
        where('conversationId', '==', activeConversationId),
        where('receiverId', '==', currentUid)
      );
      const unsubRecv = onSnapshot(
        qRecv,
        (snap) => {
          receiverDocs = snap.docs;
          updateAll();
        },
        () => {}
      );
      unsubs.push(unsubRecv);
    } catch {}

    try {
      const qSend = query(
        collection(firestoreInstance, 'messages'),
        where('conversationId', '==', activeConversationId),
        where('senderId', '==', currentUid)
      );
      const unsubSend = onSnapshot(
        qSend,
        (snap) => {
          senderDocs = snap.docs;
          updateAll();
        },
        () => {}
      );
      unsubs.push(unsubSend);
    } catch {}

    return () => {
      isCancelled = true;
      unsubs.forEach((u) => u());
    };
  }, [activeConversationId, currentUser?.uid]);

  const getDraftMessage = (conversationId: string): string => {
    return draftsRef.current[conversationId] || '';
  };

  const clearDraftMessage = (conversationId: string) => {
    delete draftsRef.current[conversationId];
  };

  const getMessagesForConversation = (conversationId: string): MessageModel[] => {
    const list = messagesMap[conversationId] || [];
    const seen = new Set<string>();
    return list.filter((m) => {
      if (!m.id || seen.has(m.id)) return false;
      seen.add(m.id);
      return true;
    });
  };

  const activeConversation = conversations.find((c) => c.id === activeConversationId) || null;
  const activeMessages = activeConversationId ? getMessagesForConversation(activeConversationId) : [];
  const totalUnreadCount = conversations.reduce((sum, c) => {
    if (c.lastSender === currentUser?.uid) return sum;
    return sum + (c.unreadCount || 0);
  }, 0);

  const openOrCreateConversation = (property: PropertyModel): string => {
    if (!currentUser) return '';

    const ownerId = (property.ownerId || (property as any).userId || (property as any).uid || (property as any).sellerId || '').trim();
    const currentUid = currentUser.uid.trim();

    // Prevent chatting with self
    if (ownerId === currentUid) {
      alert('You are the owner of this commercial property listing.');
      return '';
    }

    if (!ownerId) {
      console.warn('[RentMyShop] Property has no valid ownerId:', property.id);
      return '';
    }

    // Consistent conversation ID for both participants (sorted)
    const participants = [currentUid, ownerId].sort();
    const newConvId = `conv_${property.id}_${participants.join('_')}`;

    const defaultMsg = `Hi ${property.ownerName || 'Owner'}, I'm interested in viewing "${property.title}". Is it currently available for commercial lease inspection?`;

    const existing = conversations.find(
      (c) =>
        c.id === newConvId ||
        ((c.shopId === property.id || c.propertyId === property.id) &&
          Array.isArray(c.participants) &&
          c.participants.includes(currentUid) &&
          c.participants.includes(ownerId))
    );

    if (existing) {
      setActiveConversationId(existing.id);
      markAsSeen(existing.id);
      const existingMsgs = messagesMap[existing.id] || [];
      if (existingMsgs.length === 0) {
        draftsRef.current[existing.id] = defaultMsg;
      }
      return existing.id;
    }

    // If conversation was previously deleted locally, restore for new chat
    try {
      const deletedList: string[] = JSON.parse(
        localStorage.getItem(`rentmyshop_deleted_convs_${currentUid}`) || '[]'
      );
      if (deletedList.includes(newConvId)) {
        const updated = deletedList.filter((id) => id !== newConvId);
        localStorage.setItem(`rentmyshop_deleted_convs_${currentUid}`, JSON.stringify(updated));
      }
    } catch {}

    // Prepare conversation draft without automatically sending a message
    draftsRef.current[newConvId] = defaultMsg;

    // Create new conversation
    const nowIso = new Date().toISOString();
    const newConv: ConversationModel = {
      id: newConvId,
      participants: participants,
      participantNames: {
        [currentUid]: currentUser.fullName || 'User',
        [ownerId]: property.ownerName || 'Property Owner',
      },
      participantAvatars: {
        [currentUid]: currentUser.profileImage || '',
        [ownerId]: property.ownerImage || '',
      },
      lastMessage: '',
      lastMessageTime: 'Just now',
      lastMessageTimestamp: nowIso,
      lastSender: currentUid,
      unreadCount: 0,
      shopId: property.id,
      propertyId: property.id,
      shopTitle: property.title,
      propertyTitle: property.title,
      shopThumbnail: property.thumbnail || property.images?.[0] || '',
      propertyThumbnail: property.thumbnail || property.images?.[0] || '',
      shopPrice: property.price,
      propertyPrice: property.price,
      shopPurpose: property.purpose,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    if (firestoreInstance) {
      setDoc(doc(firestoreInstance, 'conversations', newConvId), newConv, { merge: true }).catch((err) => {
        console.warn('[RentMyShop] Error creating conversation in Firestore:', err);
      });
    }

    setConversations((prev) => {
      const updated = [newConv, ...prev.filter((c) => c.id !== newConvId)];
      localStorage.setItem(`rentmyshop_convs_${currentUid}`, JSON.stringify(updated));
      return updated;
    });

    setActiveConversationId(newConvId);
    return newConvId;
  };

  const selectConversation = (id: string) => {
    setActiveConversationId(id);
    markAsSeen(id);
  };

  const markAsSeen = async (conversationId: string) => {
    const conv = conversations.find((c) => c.id === conversationId);
    setConversations((prev) =>
      prev.map((c) => (c.id === conversationId ? { ...c, unreadCount: 0 } : c))
    );
    setMessagesMap((prev) => {
      const list = prev[conversationId];
      if (!list) return prev;
      return {
        ...prev,
        [conversationId]: list.map((m) => ({ ...m, seen: true })),
      };
    });
    if (firestoreInstance) {
      try {
        if (!conv?.lastSender || conv.lastSender !== currentUser?.uid) {
          await updateDoc(doc(firestoreInstance, 'conversations', conversationId), {
            unreadCount: 0,
          });
        }
      } catch (e) {}
    }
  };

  const sendMessage = async (conversationId: string, text: string, directReceiverId?: string) => {
    if (!currentUser || !text.trim()) return;
    const currentUid = currentUser.uid.trim();

    let conv = conversations.find((c) => c.id === conversationId);
    if (!conv && firestoreInstance) {
      try {
        const snap = await getDoc(doc(firestoreInstance, 'conversations', conversationId));
        if (snap.exists()) {
          conv = { id: snap.id, ...snap.data() } as ConversationModel;
        }
      } catch (e) {}
    }

    let receiverId = directReceiverId || '';
    if (!receiverId && conv?.participants && Array.isArray(conv.participants)) {
      receiverId = conv.participants.find((p) => p && p.trim() !== currentUid) || '';
    }
    if (!receiverId && conversationId && conversationId.startsWith('conv_')) {
      const parts = conversationId.split('_');
      const uids = parts.slice(-2);
      receiverId = uids.find((u) => u && u.trim() !== currentUid) || '';
    }

    // Always preserve both users in participants array (never remove a participant)
    const existingParticipants = Array.isArray(conv?.participants) ? conv.participants : [];
    const resolvedParticipants = Array.from(
      new Set([...existingParticipants, currentUid, ...(receiverId ? [receiverId] : [])].filter(Boolean))
    ).sort();

    const nowIso = new Date().toISOString();
    const newMsg: MessageModel = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      conversationId,
      senderId: currentUid,
      receiverId: receiverId || (resolvedParticipants.find((p) => p !== currentUid) || ''),
      message: text.trim(),
      text: text.trim(),
      messageType: 'text',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      createdAt: nowIso,
      seen: false,
      deleted: false,
    };

    if (firestoreInstance) {
      try {
        await setDoc(doc(firestoreInstance, 'messages', newMsg.id), {
          ...newMsg,
          participants: resolvedParticipants,
        });

        const conversationUpdate: any = {
          id: conversationId,
          lastMessage: text.trim(),
          lastMessageTime: 'Just now',
          lastMessageTimestamp: nowIso,
          lastSender: currentUid,
          updatedAt: nowIso,
          unreadCount: ((conv?.unreadCount || 0) + 1),
          participants: resolvedParticipants,
        };
        if (conv?.shopId) conversationUpdate.shopId = conv.shopId;
        if (conv?.propertyId) conversationUpdate.propertyId = conv.propertyId;
        if (conv?.shopTitle) conversationUpdate.shopTitle = conv.shopTitle;
        if (conv?.propertyTitle) conversationUpdate.propertyTitle = conv.propertyTitle;
        if (conv?.shopThumbnail) conversationUpdate.shopThumbnail = conv.shopThumbnail;
        if (conv?.propertyThumbnail) conversationUpdate.propertyThumbnail = conv.propertyThumbnail;
        if (conv?.shopPrice) conversationUpdate.shopPrice = conv.shopPrice;
        if (conv?.propertyPrice) conversationUpdate.propertyPrice = conv.propertyPrice;
        if (conv?.participantNames) conversationUpdate.participantNames = conv.participantNames;
        if (conv?.participantAvatars) conversationUpdate.participantAvatars = conv.participantAvatars;

        await setDoc(
          doc(firestoreInstance, 'conversations', conversationId),
          conversationUpdate,
          { merge: true }
        );

        if (receiverId) {
          const notifId = `notif_${Date.now()}`;
          setDoc(doc(firestoreInstance, 'notifications', notifId), {
            id: notifId,
            receiverId,
            title: `New message from ${currentUser.fullName || 'User'}`,
            body: text.trim().length > 60 ? `${text.trim().substring(0, 60)}...` : text.trim(),
            type: 'chat',
            isRead: false,
            createdAt: nowIso,
            relatedId: conversationId,
          }).catch((notifErr) => {
            console.warn('[RentMyShop] Notification dispatch notice (non-blocking):', notifErr);
          });
        }
      } catch (err: any) {
        console.error('[RentMyShop] Firestore message sending error:', {
          code: err?.code,
          message: err?.message,
          conversationId,
        });
        throw err;
      }
    }

    setMessagesMap((prev) => {
      const currentList = prev[conversationId] || [];
      if (currentList.some((m) => m.id === newMsg.id)) {
        return prev;
      }
      const next = { ...prev, [conversationId]: [...currentList, newMsg] };
      localStorage.setItem(`rentmyshop_msgs_${currentUid}`, JSON.stringify(next));
      return next;
    });

    setConversations((prev) => {
      const updated = prev.map((c) =>
        c.id === conversationId
          ? {
              ...c,
              lastMessage: text.trim(),
              lastMessageTime: 'Just now',
              lastMessageTimestamp: nowIso,
              lastSender: currentUid,
              unreadCount: 0,
            }
          : c
      );
      localStorage.setItem(`rentmyshop_convs_${currentUid}`, JSON.stringify(updated));
      return updated;
    });
  };

  const deleteMessage = (messageId: string) => {
    if (!activeConversationId || !currentUser) return;
    setMessagesMap((prev) => {
      const next = {
        ...prev,
        [activeConversationId]: (prev[activeConversationId] || []).filter((m) => m.id !== messageId),
      };
      localStorage.setItem(`rentmyshop_msgs_${currentUser.uid}`, JSON.stringify(next));
      return next;
    });
    if (firestoreInstance) {
      deleteDoc(doc(firestoreInstance, 'messages', messageId)).catch(() => {});
    }
  };

  const deleteConversation = async (conversationId: string): Promise<void> => {
    if (!currentUser) {
      throw new Error('You must be signed in to delete conversations.');
    }
    const currentUid = currentUser.uid.trim();

    // Check existing conversation in state or Firestore
    const conv = conversations.find((c) => c.id === conversationId);
    let convDocData: any = conv || null;

    if (firestoreInstance) {
      try {
        const convRef = doc(firestoreInstance, 'conversations', conversationId);
        const snap = await getDoc(convRef);
        if (snap.exists()) {
          convDocData = snap.data();
        }
      } catch (err: any) {
        console.warn('[RentMyShop] Notice: reading conversation doc prior to deletion:', err);
      }
    }

    // Verify participant authorization
    const participants: string[] = Array.isArray(convDocData?.participants)
      ? convDocData.participants
      : (conv?.participants || []);

    if (participants.length > 0 && !participants.includes(currentUid)) {
      throw new Error('Unauthorized: You are not a participant in this conversation.');
    }

    // Handle Firestore deletion / privacy scope
    if (firestoreInstance) {
      try {
        const convRef = doc(firestoreInstance, 'conversations', conversationId);
        const existingDeletedBy: string[] = Array.isArray(convDocData?.deletedBy)
          ? convDocData.deletedBy
          : [];
        const updatedDeletedBy = Array.from(new Set([...existingDeletedBy, currentUid]));

        // Check if all participants requested deletion
        const allParticipantsDeleted =
          participants.length > 0 &&
          participants.every((p) => updatedDeletedBy.includes(p));

        if (allParticipantsDeleted) {
          // If all participants chose to delete, permanently remove conversation document
          await deleteDoc(convRef);
        } else {
          // Keep counterparty conversation intact while marking deleted for current user
          await updateDoc(convRef, {
            deletedBy: updatedDeletedBy,
          });
        }

        // Clean up current user's sent messages in Firestore (per rule: senderId == auth.uid)
        const msgsList = messagesMap[conversationId] || [];
        for (const msg of msgsList) {
          if (msg.senderId === currentUid) {
            deleteDoc(doc(firestoreInstance, 'messages', msg.id)).catch(() => {});
          }
        }
      } catch (err: any) {
        console.error('[RentMyShop] Firestore conversation deletion error:', err);
        throw new Error(err?.message || 'Failed to delete conversation from server. Please try again.');
      }
    }

    // Persist locally so deleted chat never reappears after refresh or re-login
    try {
      const deletedList: string[] = JSON.parse(
        localStorage.getItem(`rentmyshop_deleted_convs_${currentUid}`) || '[]'
      );
      if (!deletedList.includes(conversationId)) {
        deletedList.push(conversationId);
        localStorage.setItem(
          `rentmyshop_deleted_convs_${currentUid}`,
          JSON.stringify(deletedList)
        );
      }
    } catch {}

    // Update conversations in state and localStorage
    setConversations((prev) => {
      const updated = prev.filter((c) => c.id !== conversationId);
      localStorage.setItem(`rentmyshop_convs_${currentUid}`, JSON.stringify(updated));
      return updated;
    });

    // Update messagesMap in state and localStorage
    setMessagesMap((prev) => {
      const next = { ...prev };
      delete next[conversationId];
      localStorage.setItem(`rentmyshop_msgs_${currentUid}`, JSON.stringify(next));
      return next;
    });

    // Clear drafts and active state if active
    delete draftsRef.current[conversationId];
    if (activeConversationId === conversationId) {
      setActiveConversationId(null);
    }
  };

  return (
    <ChatContext.Provider
      value={{
        conversations,
        activeConversation,
        activeMessages,
        isTyping,
        totalUnreadCount,
        openOrCreateConversation,
        selectConversation,
        sendMessage,
        markAsSeen,
        deleteMessage,
        deleteConversation,
        getMessagesForConversation,
        getDraftMessage,
        clearDraftMessage,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};

