/**
 * RentMyShop AI Customer Support Widget
 * Compact floating customer-support agent powered by Gemini AI.
 * Grounded in real RentMyShop marketplace listings and platform features.
 */
import React, { useState, useEffect, useRef } from 'react';
import { useProperties } from '../../context/PropertyContext';
import { 
  Bot, 
  X, 
  Send, 
  RotateCcw, 
  Sparkles, 
  AlertCircle, 
  Store,
  ChevronDown,
  Building2,
  ExternalLink
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

const INITIAL_WELCOME_MESSAGE: ChatMessage = {
  id: 'welcome_msg',
  role: 'assistant',
  content: `Hello! I'm **RentMyShop**, your AI commercial property assistant.\n\nI can help you:\n• Find verified shops, offices, plazas, and warehouses across Pakistan\n• Understand listing prices, lease terms, and locations\n• Learn how to list your commercial property or contact owners\n\nHow can I help you today?`,
  timestamp: 'Just now',
};

const QUICK_SUGGESTIONS = [
  'Shops for rent in Lahore',
  'Commercial offices in Karachi',
  'How do I list my shop?',
  'How does in-app chat work?',
];

export const SupportChatWidget: React.FC = () => {
  const { properties } = useProperties();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = sessionStorage.getItem('rentmyshop_support_chat');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [INITIAL_WELCOME_MESSAGE];
  });
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isServiceOnline, setIsServiceOnline] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync session storage
  useEffect(() => {
    try {
      sessionStorage.setItem('rentmyshop_support_chat', JSON.stringify(messages));
    } catch {}
  }, [messages]);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading, isOpen]);

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 150);
    }
  }, [isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || isLoading) return;

    const userMessage: ChatMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    if (!textToSend) setInput('');
    setIsLoading(true);
    setErrorMessage(null);

    // Sanitize non-deleted public listings to ground Gemini
    const publicListings = (properties || [])
      .filter((p) => !p.isDeleted)
      .slice(0, 30)
      .map((p) => ({
        id: p.id,
        title: p.title,
        purpose: p.purpose,
        category: p.category,
        price: p.price,
        city: p.city,
        area: p.area,
        isVerified: p.isVerified,
        description: p.description ? p.description.slice(0, 150) : '',
      }));

    try {
      const res = await fetch('/api/support-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          publicListings,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setIsServiceOnline(false);
        const errMsg = data?.error || 'Unable to get response from RentMyShop AI.';
        setErrorMessage(errMsg);
        return;
      }

      setIsServiceOnline(true);
      const assistantMessage: ChatMessage = {
        id: `ast_${Date.now()}`,
        role: 'assistant',
        content: data.reply || 'I am ready to help with your commercial property queries.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('[RentMyShop AI] Support chat error:', err);
      setIsServiceOnline(false);
      setErrorMessage(
        'Connection interrupted. Please ensure your network is active and try again.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetChat = () => {
    setMessages([INITIAL_WELCOME_MESSAGE]);
    setErrorMessage(null);
    setIsServiceOnline(true);
    try {
      sessionStorage.removeItem('rentmyshop_support_chat');
    } catch {}
  };

  return (
    <>
      {/* Collapsed Floating Launcher Button */}
      {!isOpen && (
        <button
          type="button"
          id="rentmyshop-ai-support-launcher"
          onClick={() => setIsOpen(true)}
          title="RentMyShop AI Support"
          aria-label="Open RentMyShop AI Support"
          className="fixed bottom-20 md:bottom-6 right-4 md:right-6 z-50 w-14 h-14 rounded-full bg-[#FF6B00] hover:bg-[#E55F00] text-white shadow-xl shadow-[#FF6B00]/35 flex items-center justify-center cursor-pointer transition-all duration-200 active:scale-95 group focus:outline-none focus:ring-4 focus:ring-[#FF6B00]/30"
        >
          {/* Animated online status dot */}
          <span className="absolute top-1 right-1 flex h-3.5 w-3.5">
            <span
              className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                isServiceOnline ? 'bg-emerald-400' : 'bg-amber-400'
              }`}
            />
            <span
              className={`relative inline-flex rounded-full h-3.5 w-3.5 border-2 border-white ${
                isServiceOnline ? 'bg-emerald-500' : 'bg-amber-500'
              }`}
            />
          </span>

          <Bot className="w-7 h-7 transition-transform group-hover:scale-110" />
        </button>
      )}

      {/* Expanded Chat Widget Panel */}
      {isOpen && (
        <div
          id="rentmyshop-ai-support-panel"
          className="fixed bottom-20 md:bottom-6 right-4 md:right-6 z-50 w-[calc(100vw-2rem)] sm:w-[380px] h-[520px] max-h-[calc(100vh-6rem)] rounded-[24px] shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 transition-all animate-in fade-in zoom-in-95 duration-150"
        >
          {/* Header */}
          <div className="px-4 py-3 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 shadow-xs">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-full bg-[#FFF5EE] dark:bg-orange-950/40 text-[#FF6B00] flex items-center justify-center shrink-0 ring-1 ring-[#FF6B00]/20">
                <Bot className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 truncate">
                    RentMyShop
                  </h3>
                  {/* Status Indicator */}
                  {isServiceOnline ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-800/50">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span>Online</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border border-amber-200/50 dark:border-amber-800/50">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                      <span>Offline</span>
                    </span>
                  )}
                </div>
               
              </div>
            </div>

            {/* Header Actions */}
            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={handleResetChat}
                title="Start new conversation"
                aria-label="Start new conversation"
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                title="Minimize support chat"
                aria-label="Minimize support chat"
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <ChevronDown className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Conversation Scroll Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#F8F9FA] dark:bg-slate-900/60">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[85%] px-3.5 py-2.5 text-xs leading-relaxed font-medium shadow-xs ${
                    msg.role === 'user'
                      ? 'bg-[#FF6B00] text-white rounded-[18px] rounded-br-xs'
                      : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-100 dark:border-slate-700 rounded-[18px] rounded-bl-xs'
                  }`}
                >
                  <div className="whitespace-pre-wrap space-y-1">
                    {msg.content}
                  </div>
                </div>
                <span className="text-[9px] text-slate-400 mt-1 px-1">
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {/* Quick Suggestion Chips (when only initial welcome is present) */}
            {messages.length === 1 && !isLoading && (
              <div className="pt-2 space-y-1.5">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-1">
                  Suggested inquiries
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {QUICK_SUGGESTIONS.map((suggestion) => (
                    <button
                      key={suggestion}
                      type="button"
                      onClick={() => handleSendMessage(suggestion)}
                      className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 hover:border-[#FF6B00] hover:text-[#FF6B00] border border-slate-200 dark:border-slate-700 px-2.5 py-1.5 rounded-full shadow-2xs transition-all text-left cursor-pointer active:scale-95"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Typing Indicator */}
            {isLoading && (
              <div className="flex items-center gap-1.5 text-xs text-slate-500 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 w-fit px-3 py-2 rounded-[16px] rounded-bl-xs shadow-2xs">
                <Sparkles className="w-3.5 h-3.5 text-[#FF6B00] animate-spin" />
                <span className="font-semibold text-[11px]">RentMyShop is typing...</span>
              </div>
            )}

            {/* Error Message with Retry */}
            {errorMessage && (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 rounded-[16px] text-rose-700 dark:text-rose-300 text-xs space-y-2">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="font-medium text-[11px] leading-snug">{errorMessage}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleSendMessage(input || messages[messages.length - 1]?.content)}
                  className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-[8px] text-[10px] font-bold cursor-pointer transition-colors"
                >
                  Retry Request
                </button>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about shops, offices, pricing..."
                disabled={isLoading}
                className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[14px] px-3.5 py-2.5 text-xs font-semibold text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-[#FF6B00] transition-colors disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                title="Send message"
                aria-label="Send message"
                className="w-9 h-9 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] disabled:bg-slate-200 dark:disabled:bg-slate-800 text-white disabled:text-slate-400 flex items-center justify-center shrink-0 shadow-md shadow-[#FF6B00]/20 disabled:shadow-none transition-all cursor-pointer disabled:cursor-not-allowed active:scale-95"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
            <p className="text-[9px] text-center text-slate-400 mt-1.5 font-medium">
              Grounded in verified platform listings • Commercial support only
            </p>
          </div>
        </div>
      )}
    </>
  );
};
