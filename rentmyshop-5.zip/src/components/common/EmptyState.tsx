/**
 * RentMyShop Reusable Empty State Component
 */
import React from 'react';
import { LucideIcon } from 'lucide-react';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon: Icon,
  title,
  description,
  actionLabel,
  onAction,
}) => {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8 bg-white rounded-[24px] border border-slate-100 max-w-md mx-auto my-6 shadow-xs">
      <div className="w-16 h-16 rounded-full bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center mb-4 ring-8 ring-[#FFF5EE]/50">
        <Icon className="w-8 h-8 stroke-[1.8]" />
      </div>
      <h3 className="text-lg font-bold text-slate-900 mb-1.5">{title}</h3>
      <p className="text-sm text-slate-500 mb-6 leading-relaxed max-w-xs">{description}</p>
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="px-6 py-2.5 rounded-[14px] bg-[#FF6B00] text-white text-sm font-bold shadow-md shadow-[#FF6B00]/25 hover:bg-[#E55F00] active:scale-95 transition-all"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
};
