/**
 * RentMyShop Application Header Component
 * Provides dynamic time-based greeting, Pakistan-wide location selector with search,
 * notification badge, and search trigger.
 */
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import { useProperties } from '../../context/PropertyContext';
import { 
  Bell, 
  MapPin, 
  ChevronDown, 
  Search, 
  SlidersHorizontal, 
  Navigation, 
  Check,
  ArrowLeft,
  X,
  User as UserIcon
} from 'lucide-react';
import { 
  PAKISTAN_CITIES, 
  POPULAR_COMMERCIAL_CITIES, 
  LocationService 
} from '../../services/locationService';

export interface HeaderProps {
  title?: string;
  isNested?: boolean;
  onBack?: () => void;
  onOpenNotifications: () => void;
  onOpenProfile?: () => void;
  onOpenExploreWithSearch?: () => void;
  onOpenFilters?: () => void;
  notificationCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  isNested,
  onBack,
  onOpenNotifications,
  onOpenProfile,
  onOpenExploreWithSearch,
  onOpenFilters,
  notificationCount,
}) => {
  const { currentUser } = useAuth();
  const { unreadCount: contextUnread } = useNotifications();
  const effectiveUnread = notificationCount !== undefined ? notificationCount : contextUnread;
  const { selectedCity, setSelectedCity, searchQuery, setSearchQuery } = useProperties();
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [citySearchInput, setCitySearchInput] = useState('');
  const [isLocating, setIsLocating] = useState(false);

  // Dynamic greeting based on current local time
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const handleUseCurrentLocation = async () => {
    setIsLocating(true);
    try {
      const loc = await LocationService.getCurrentLocation();
      if (loc.city) {
        setSelectedCity(loc.city);
      }
    } finally {
      setIsLocating(false);
      setShowCityPicker(false);
    }
  };

  const filteredPickerCities = citySearchInput.trim()
    ? PAKISTAN_CITIES.filter((c) => {
        const query = citySearchInput.toLowerCase().trim();
        const nameMatch = c.city.toLowerCase().includes(query);
        const provMatch = c.province.toLowerCase().includes(query);
        const aliasMatch = c.aliases?.some((a) => a.toLowerCase().includes(query));
        return nameMatch || provMatch || aliasMatch;
      })
    : POPULAR_COMMERCIAL_CITIES;

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-100 px-4 pt-3 pb-3 transition-all">
      <div className="max-w-7xl mx-auto flex flex-col gap-3">
        {/* Top Row: Greeting, Location & Actions OR Nested Title Bar */}
        {isNested && title ? (
          <div className="flex items-center justify-between gap-3 h-10">
            <div className="flex items-center gap-3">
              {onBack && (
                <button
                  onClick={onBack}
                  className="w-10 h-10 rounded-full bg-slate-50 hover:bg-slate-100 border border-slate-200/80 flex items-center justify-center text-slate-700 active:scale-95 transition-all"
                  aria-label="Go back"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
              )}
              <h1 className="text-lg font-extrabold text-slate-900 tracking-tight">
                {title}
              </h1>
            </div>
            <div className="flex items-center gap-2">
              <button
                id="notifications-nav-btn"
                onClick={onOpenNotifications}
                aria-label="Open notifications"
                className="relative w-10 h-10 rounded-[14px] bg-slate-50 border border-slate-200/80 flex items-center justify-center text-slate-700 hover:bg-slate-100 transition-colors active:scale-95"
              >
                <Bell className="w-5 h-5" />
                {effectiveUnread > 0 && (
                  <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#FF6B00] rounded-full ring-2 ring-white animate-pulse" />
                )}
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-3">
            {/* Brand & Greeting */}
            <div className="flex items-center gap-3">
              <div 
                onClick={onOpenProfile}
                className="relative w-10 h-10 rounded-full ring-2 ring-[#FF6B00]/20 p-0.5 cursor-pointer active:scale-95 transition-transform shrink-0"
              >
                {currentUser?.profileImage ? (
                  <img
                    src={currentUser.profileImage}
                    alt={currentUser.fullName || 'User'}
                    referrerPolicy="no-referrer"
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full rounded-full bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center font-bold text-sm">
                    {currentUser?.fullName ? currentUser.fullName.charAt(0).toUpperCase() : <UserIcon className="w-4 h-4" />}
                  </div>
                )}
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white" />
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-400">
                  {getGreeting()}{currentUser?.fullName ? `, ${currentUser.fullName.split(' ')[0]}` : (currentUser?.email ? `, ${currentUser.email.split('@')[0]}` : '')}
                </p>
                {/* Location Picker Trigger */}
                <div className="relative">
                  <button
                    id="header-location-picker-btn"
                    onClick={() => {
                      setShowCityPicker(!showCityPicker);
                      setCitySearchInput('');
                    }}
                    className="flex items-center gap-1 text-sm font-bold text-slate-800 hover:text-[#FF6B00] transition-colors"
                  >
                    <MapPin className="w-3.5 h-3.5 text-[#FF6B00]" />
                    <span className="truncate max-w-[140px] sm:max-w-[200px]">{selectedCity}</span>
                    <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${showCityPicker ? 'rotate-180' : ''}`} />
                  </button>

                  {/* Dropdown City Menu */}
                  {showCityPicker && (
                    <div className="absolute top-full left-0 mt-2 w-72 max-h-96 bg-white rounded-[18px] shadow-2xl border border-slate-100 p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-200 flex flex-col">
                      <div className="px-2 pt-1 pb-2">
                        <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                          Commercial Hubs (Pakistan)
                        </p>
                        {/* Quick filter inside dropdown */}
                        <div className="relative flex items-center bg-slate-50 rounded-[10px] px-2.5 py-1.5 border border-slate-200">
                          <Search className="w-3.5 h-3.5 text-slate-400 mr-1.5 shrink-0" />
                          <input
                            type="text"
                            placeholder="Search any Pakistan city..."
                            value={citySearchInput}
                            onChange={(e) => setCitySearchInput(e.target.value)}
                            className="w-full bg-transparent text-xs font-medium text-slate-800 outline-hidden placeholder-slate-400"
                            autoFocus
                          />
                        </div>
                      </div>

                      <div className="overflow-y-auto flex-1 divide-y divide-slate-50">
                        <button
                          onClick={handleUseCurrentLocation}
                          disabled={isLocating}
                          className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-[#FF6B00] hover:bg-[#FFF5EE] rounded-[10px] transition-colors mb-1"
                        >
                          <Navigation className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
                          <span>{isLocating ? 'Detecting Location...' : 'Use Current Location'}</span>
                        </button>

                        <button
                          onClick={() => {
                            setSelectedCity('All Cities');
                            setShowCityPicker(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-[10px] transition-colors ${
                            selectedCity === 'All Cities'
                              ? 'bg-slate-100 text-slate-900 font-bold'
                              : 'text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          <span>All Cities (Pakistan)</span>
                          {selectedCity === 'All Cities' && <Check className="w-3.5 h-3.5 text-[#FF6B00]" />}
                        </button>

                        {filteredPickerCities.map((c) => (
                          <button
                            key={c.city}
                            onClick={() => {
                              setSelectedCity(c.city);
                              setShowCityPicker(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-[10px] transition-colors ${
                              selectedCity.toLowerCase() === c.city.toLowerCase()
                                ? 'bg-slate-100 text-slate-900 font-bold'
                                : 'text-slate-600 hover:bg-slate-50'
                            }`}
                          >
                            <span>{c.city}, {'province' in c ? (c as any).province : (c as any).state}</span>
                            {selectedCity.toLowerCase() === c.city.toLowerCase() && (
                              <Check className="w-3.5 h-3.5 text-[#FF6B00]" />
                            )}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right Action: Notification Bell */}
            <div className="flex items-center gap-2">
              <button
                id="notifications-nav-btn"
                onClick={onOpenNotifications}
                aria-label="Open notifications"
                className="relative w-10 h-10 rounded-[14px] bg-slate-50 border border-slate-200/80 flex items-center justify-center text-slate-700 hover:bg-slate-100 transition-colors active:scale-95"
              >
                <Bell className="w-5 h-5" />
                {effectiveUnread > 0 && (
                  <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#FF6B00] rounded-full ring-2 ring-white animate-pulse" />
                )}
              </button>
            </div>
          </div>
        )}

        {/* Bottom Row: Prominent Search Input with Filter Trigger on Home/Explore */}
        {!isNested && (
          <div className="flex items-center gap-2">
            <div 
              onClick={() => {
                document.getElementById('header-search-input')?.focus();
              }}
              className="flex-1 relative flex items-center bg-slate-100/90 hover:bg-slate-100 rounded-[14px] px-3.5 py-2.5 transition-all border border-transparent focus-within:border-[#FF6B00] focus-within:bg-white focus-within:ring-2 focus-within:ring-[#FF6B00]/10 cursor-text"
            >
              <Search className="w-4.5 h-4.5 text-slate-400 mr-2.5 shrink-0 cursor-pointer" />
              <input
                id="header-search-input"
                type="text"
                placeholder="Search shops, offices, warehouses, city..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    (e.target as HTMLInputElement).blur();
                  }
                }}
                className="w-full bg-transparent text-sm text-slate-800 placeholder-slate-400 outline-hidden font-medium"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSearchQuery('');
                  }}
                  aria-label="Clear search"
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-full shrink-0 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            {onOpenFilters && (
              <button
                id="header-filter-btn"
                onClick={onOpenFilters}
                aria-label="Filter properties"
                className="w-11 h-11 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white flex items-center justify-center shadow-md shadow-[#FF6B00]/20 active:scale-95 transition-all"
              >
                <SlidersHorizontal className="w-4.5 h-4.5" />
              </button>
            )}
          </div>
        )}
      </div>
    </header>
  );
};
