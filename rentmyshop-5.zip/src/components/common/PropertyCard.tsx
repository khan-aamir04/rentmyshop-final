/**
 * RentMyShop Reusable PropertyCard Widget
 * Strictly implements the approved 18px radius, soft shadow, rent/sale badge,
 * verified badge, favorite heart animation, and commercial property metadata.
 */
import React from 'react';
import { PropertyModel } from '../../types';
import { useProperties } from '../../context/PropertyContext';
import { 
  Heart, 
  MapPin, 
  Maximize2, 
  ShieldCheck, 
  Clock, 
  Images, 
  Sparkles 
} from 'lucide-react';

interface PropertyCardProps {
  property: PropertyModel;
  onClick: (property: PropertyModel) => void;
  horizontal?: boolean;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ 
  property, 
  onClick, 
  horizontal = false 
}) => {
  const { toggleFavorite, isFavorite } = useProperties();
  const favorited = isFavorite(property.id);

  const priceNum = property.price || 0;
  const formattedPrice = priceNum >= 1000
    ? `PKR ${priceNum.toLocaleString()}`
    : `PKR ${priceNum}`;

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(property.id);
  };

  const imagesCount = property.images?.length || 1;
  const imageSource = property.thumbnail || property.images?.[0] || 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600';

  return (
    <div
      id={`property-card-${property.id}`}
      onClick={() => onClick(property)}
      className={`group relative bg-white rounded-[18px] border border-slate-100 shadow-[0_4px_20px_-4px_rgba(15,23,42,0.06)] hover:shadow-[0_12px_28px_-6px_rgba(15,23,42,0.12)] transition-all duration-300 cursor-pointer overflow-hidden flex flex-col ${
        horizontal ? 'min-w-[280px] sm:min-w-[320px] max-w-[340px]' : 'w-full'
      }`}
    >
      {/* Image Container */}
      <div className="relative aspect-[16/10] w-full overflow-hidden bg-slate-100">
        <img
          src={imageSource}
          alt={property.title || 'Commercial Property'}
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        {/* Gradient Overlay for legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/20 pointer-events-none" />

        {/* Rent / Sale Badge */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5 z-10">
          <span
            className={`px-2.5 py-1 text-xs font-bold uppercase tracking-wider rounded-full shadow-sm text-white ${
              property.purpose === 'rent'
                ? 'bg-[#FF6B00]'
                : 'bg-emerald-600'
            }`}
          >
            For {property.purpose}
          </span>
          {property.isFeatured && (
            <span className="flex items-center gap-1 px-2 py-1 text-xs font-semibold rounded-full bg-amber-500/90 text-white backdrop-blur-xs shadow-sm">
              <Sparkles className="w-3 h-3" />
              Featured
            </span>
          )}
        </div>

        {/* Favorite Button with Micro-Animation */}
        <button
          id={`favorite-btn-${property.id}`}
          onClick={handleFavoriteClick}
          aria-label="Save property"
          className="absolute top-3 right-3 z-10 w-9 h-9 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center shadow-md transition-transform active:scale-90 hover:scale-105 hover:bg-white"
        >
          <Heart
            className={`w-4.5 h-4.5 transition-colors duration-200 ${
              favorited
                ? 'fill-rose-500 text-rose-500'
                : 'text-slate-700 hover:text-rose-500'
            }`}
          />
        </button>

        {/* Image Count & Category Pill */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-white/90 font-medium z-10">
          <span className="px-2 py-0.5 rounded-md bg-black/50 backdrop-blur-xs flex items-center gap-1">
            <Images className="w-3 h-3" />
            {imagesCount} photos
          </span>
          <span className="px-2 py-0.5 rounded-md bg-black/50 backdrop-blur-xs">
            {property.category}
          </span>
        </div>
      </div>

      {/* Content Area */}
      <div className="p-4 flex flex-col flex-1 justify-between gap-3">
        <div>
          {/* Price Header */}
          <div className="flex items-baseline justify-between gap-2 mb-1">
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-extrabold text-slate-900 tracking-tight">
                {formattedPrice}
              </span>
              {property.purpose === 'rent' && (
                <span className="text-xs font-semibold text-slate-500">
                  {property.pricePeriod || '/mo'}
                </span>
              )}
            </div>
            {property.isVerified && (
              <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Verified
              </span>
            )}
          </div>

          {/* Title */}
          <h3 className="font-bold text-slate-900 text-base line-clamp-1 group-hover:text-[#FF6B00] transition-colors">
            {property.title}
          </h3>

          {/* Location */}
          <p className="flex items-center gap-1.5 text-xs text-slate-500 mt-1 line-clamp-1">
            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>{property.address}, {property.city}</span>
          </p>
        </div>

        {/* Bottom Metadata & Specs */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600 font-medium">
          <div className="flex items-center gap-1 text-slate-700">
            <Maximize2 className="w-3.5 h-3.5 text-slate-400" />
            <span>{(property.area || 0).toLocaleString()} sq ft</span>
          </div>
          <div className="flex items-center gap-1 text-slate-400 text-[11px]">
            <Clock className="w-3.5 h-3.5" />
            <span>Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};
