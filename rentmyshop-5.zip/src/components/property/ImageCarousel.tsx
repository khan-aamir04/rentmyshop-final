/**
 * RentMyShop Property Image Carousel
 * Interactive carousel with page dots, back button, favorite toggle, and share action
 */
import React, { useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Heart, 
  Share2, 
  ArrowLeft,
  Check
} from 'lucide-react';
import { useProperties } from '../../context/PropertyContext';

interface ImageCarouselProps {
  images: string[];
  propertyId: string;
  propertyTitle: string;
  onBack: () => void;
}

export const ImageCarousel: React.FC<ImageCarouselProps> = ({
  images,
  propertyId,
  propertyTitle,
  onBack,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const { isFavorite, toggleFavorite } = useProperties();
  const favorited = isFavorite(propertyId);

  const safeImages = images && images.length > 0
    ? images
    : ['https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80'];

  const prevImage = () => {
    setCurrentIndex((prev) => (prev === 0 ? safeImages.length - 1 : prev - 1));
  };

  const nextImage = () => {
    setCurrentIndex((prev) => (prev === safeImages.length - 1 ? 0 : prev + 1));
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: propertyTitle,
          text: `Check out this commercial space on RentMyShop: ${propertyTitle}`,
          url: window.location.href,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative aspect-[16/11] sm:aspect-[16/9] w-full bg-slate-900 overflow-hidden select-none">
      {/* Active Image */}
      <img
        src={safeImages[currentIndex] || safeImages[0]}
        alt={`${propertyTitle} photo ${currentIndex + 1}`}
        referrerPolicy="no-referrer"
        className="w-full h-full object-cover transition-opacity duration-300"
      />

      {/* Subtle top and bottom gradients */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/60 pointer-events-none" />

      {/* Top Controls Bar */}
      <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between">
        {/* Back Button */}
        <button
          onClick={onBack}
          aria-label="Back"
          className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center text-slate-800 shadow-md hover:bg-white active:scale-95 transition-all"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        {/* Right Actions: Favorite & Share */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleShare}
            aria-label="Share listing"
            className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center text-slate-800 shadow-md hover:bg-white active:scale-95 transition-all"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
          </button>
          <button
            onClick={() => toggleFavorite(propertyId)}
            aria-label="Save property"
            className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center shadow-md hover:bg-white active:scale-95 transition-all"
          >
            <Heart
              className={`w-5 h-5 transition-colors ${
                favorited ? 'fill-rose-500 text-rose-500' : 'text-slate-800'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Previous / Next Arrow Buttons */}
      {safeImages.length > 1 && (
        <>
          <button
            onClick={prevImage}
            aria-label="Previous photo"
            className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 text-white flex items-center justify-center backdrop-blur-xs hover:bg-black/60 transition-colors z-20"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={nextImage}
            aria-label="Next photo"
            className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/40 text-white flex items-center justify-center backdrop-blur-xs hover:bg-black/60 transition-colors z-20"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </>
      )}

      {/* Bottom Counter and Dot Indicators */}
      <div className="absolute bottom-4 left-4 right-4 z-20 flex items-center justify-between">
        <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-xs font-semibold text-white">
          {currentIndex + 1} / {safeImages.length}
        </span>
        {/* Dots */}
        <div className="flex items-center gap-1.5">
          {safeImages.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                currentIndex === i ? 'w-5 bg-[#FF6B00]' : 'w-1.5 bg-white/60'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
