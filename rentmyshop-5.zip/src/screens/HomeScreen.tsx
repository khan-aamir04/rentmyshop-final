/**
 * RentMyShop Home Screen
 * Header, Category Cards, Featured Properties, Latest Properties,
 * Nearby Properties, and Recommended Properties.
 */
import React from 'react';
import { useProperties } from '../context/PropertyContext';
import { useAuth } from '../context/AuthContext';
import { PropertyModel, PropertyCategory } from '../types';
import { PropertyCard } from '../components/common/PropertyCard';
import { 
  Store, 
  Building2, 
  Warehouse, 
  Building, 
  ShoppingBag, 
  LandPlot, 
  ChevronRight,
  Sparkles,
  Clock,
  Compass,
  TrendingUp,
  Search,
  X
} from 'lucide-react';
import { 
  matchCitySearch, 
  matchesCity, 
  getProvinceForCity, 
  normalizeCityName, 
  CITY_ALIASES 
} from '../services/locationService';

interface HomeScreenProps {
  onSelectProperty: (property: PropertyModel) => void;
  onNavigateToExplore: (category?: PropertyCategory) => void;
  onNavigateToAdd?: () => void;
}

const CATEGORY_ICON_MAP: Record<string, React.ReactNode> = {
  Shops: <Store className="w-5 h-5" />,
  Offices: <Building2 className="w-5 h-5" />,
  Warehouses: <Warehouse className="w-5 h-5" />,
  'Commercial Plaza': <Building className="w-5 h-5" />,
  Kiosk: <ShoppingBag className="w-5 h-5" />,
  'Commercial Plot': <LandPlot className="w-5 h-5" />,
};

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onSelectProperty,
  onNavigateToExplore,
  onNavigateToAdd,
}) => {
  const { 
    properties, 
    categories, 
    setSelectedCategory, 
    searchQuery, 
    setSearchQuery, 
    selectedCity,
    filterState 
  } = useProperties();
  const { currentUser } = useAuth();
  const currentUid = (currentUser?.uid || '').trim();

  const handleCategoryClick = (catName: PropertyCategory) => {
    setSelectedCategory(catName);
    onNavigateToExplore(catName);
  };

  // Exclude personal listings from Home (they appear in My Listings)
  const isOtherUserProperty = (p: PropertyModel) => {
    if (p.isDeleted) return false;
    if (!currentUid) return true;
    const pOwner = (p.ownerId || (p as any).userId || (p as any).uid || (p as any).sellerId || '').trim();
    return pOwner !== currentUid;
  };

  const isSearchMatch = (p: PropertyModel, queryText: string) => {
    if (!queryText.trim()) return true;
    const q = queryText.trim().toLowerCase();

    // Direct purpose phrases
    if ((q === 'for rent' || q === 'rent') && p.purpose === 'rent') return true;
    if ((q === 'for sale' || q === 'sale') && p.purpose === 'sale') return true;

    const title = (p.title || '').toLowerCase();
    const desc = (p.description || '').toLowerCase();
    const addr = (p.address || '').toLowerCase();
    const city = (p.city || '').toLowerCase();
    const cat = (p.category || '').toLowerCase();
    const purpose = (p.purpose || '').toLowerCase();
    const prov = getProvinceForCity(p.city).toLowerCase();
    const facs = (p.facilities || []).join(' ').toLowerCase();

    // 1. Direct whole-string match against any field
    if (
      title.includes(q) ||
      desc.includes(q) ||
      addr.includes(q) ||
      city.includes(q) ||
      cat.includes(q) ||
      purpose.includes(q) ||
      prov.includes(q) ||
      facs.includes(q)
    ) {
      return true;
    }

    // 2. City exact or alias match (when query matches the location directly)
    const normCity = normalizeCityName(p.city);
    const normQ = normalizeCityName(q);
    if (
      matchCitySearch(p.city, q) &&
      (normCity === normQ ||
        normCity.includes(normQ) ||
        (CITY_ALIASES[normCity] || []).includes(normQ) ||
        (prov && (prov === normQ || prov.includes(normQ))))
    ) {
      return true;
    }

    // 3. Multi-word search token matching (e.g. "office in nawabshah", "rent shop", "sakrand road")
    const stopWords = new Set(['in', 'at', 'for', 'the', 'a', 'an', 'of', 'and', 'with', 'to']);
    const words = q.split(/\s+/).filter((w) => w.length > 0 && !stopWords.has(w));
    if (words.length > 0) {
      return words.every((word) => {
        if (
          title.includes(word) ||
          desc.includes(word) ||
          addr.includes(word) ||
          city.includes(word) ||
          cat.includes(word) ||
          purpose.includes(word) ||
          prov.includes(word) ||
          facs.includes(word)
        ) {
          return true;
        }
        if (matchCitySearch(p.city, word)) {
          return true;
        }
        return false;
      });
    }

    return false;
  };

  const isCityMatch = (p: PropertyModel, cName?: string) => {
    if (!cName || cName === 'all' || cName === 'All Cities') return true;
    return matchesCity(p.city, cName);
  };

  // Base marketplace listings (excluding own listings and deleted)
  const baseMarketplaceProperties = properties.filter(isOtherUserProperty);

  // Apply location filter (if selected in header or filter state)
  const activeCity = selectedCity !== 'All Cities' ? selectedCity : filterState?.city;
  const cityFilteredProperties = baseMarketplaceProperties.filter((p) => isCityMatch(p, activeCity));

  // Combined marketplace properties respecting existing filters (purpose, category)
  const filteredBase = cityFilteredProperties.filter((p) => {
    if (filterState?.purpose && filterState.purpose !== 'all' && p.purpose !== filterState.purpose) {
      return false;
    }
    if (filterState?.category && filterState.category !== 'all' && p.category !== filterState.category) {
      return false;
    }
    return true;
  });

  // Determine if search query is active
  const isSearching = Boolean(searchQuery.trim());
  const searchResults = isSearching
    ? filteredBase
        .filter((p) => isSearchMatch(p, searchQuery))
        .sort((a, b) => {
          if (filterState?.sortBy === 'price_low') return (a.price || 0) - (b.price || 0);
          if (filterState?.sortBy === 'price_high') return (b.price || 0) - (a.price || 0);
          if (filterState?.sortBy === 'oldest') {
            return new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime();
          }
          return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
        })
    : [];

  // Default listing sections when not searching
  const marketplaceProperties = filteredBase;
  const featuredProperties = marketplaceProperties.filter((p) => p.isFeatured);
  const latestProperties = [...marketplaceProperties].sort((a, b) => 
    new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
  );
  const nearbyProperties = marketplaceProperties.slice(0, 4);
  const recommendedProperties = marketplaceProperties;

  return (
    <div className="pb-28 pt-2 px-4 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-300">
      {/* 1. Horizontally Scrollable Commercial Categories */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-extrabold text-slate-900 tracking-tight flex items-center gap-1.5">
            <span>Commercial Categories</span>
          </h2>
          <button
            onClick={() => onNavigateToExplore()}
            className="text-xs font-bold text-[#FF6B00] hover:text-[#E55F00] flex items-center gap-0.5"
          >
            <span>Explore All</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-2 pt-1 -mx-4 px-4">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => handleCategoryClick(cat.name)}
              className="flex flex-col items-center justify-center p-3.5 min-w-[105px] rounded-[18px] bg-white border border-slate-100/90 shadow-[0_2px_12px_-3px_rgba(15,23,42,0.06)] hover:border-[#FF6B00]/40 hover:shadow-md hover:scale-102 active:scale-95 transition-all text-slate-800 shrink-0 group"
            >
              <div className="w-12 h-12 rounded-[14px] bg-[#FFF5EE] text-[#FF6B00] group-hover:bg-[#FF6B00] group-hover:text-white flex items-center justify-center transition-colors mb-2 shadow-xs">
                {CATEGORY_ICON_MAP[cat.name] || <Store className="w-5 h-5" />}
              </div>
              <span className="text-xs font-bold truncate max-w-[95px]">{cat.name}</span>
              <span className="text-[10px] font-semibold text-slate-400 mt-0.5">
                {cat.count} listings
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* When searching via top Home search input */}
      {isSearching ? (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-[10px] bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center shadow-2xs">
                <Search className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                  Search Results
                </h2>
                <p className="text-xs text-slate-400 font-medium">
                  {searchResults.length} {searchResults.length === 1 ? 'property' : 'properties'} found for &ldquo;{searchQuery.trim()}&rdquo;
                </p>
              </div>
            </div>
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs font-bold text-[#FF6B00] hover:text-[#E55F00] flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#FFF5EE] hover:bg-[#FFEDD5] transition-colors"
            >
              <X className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          </div>

          {searchResults.length === 0 ? (
            <div className="bg-white rounded-[24px] border border-slate-100 shadow-xs p-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
                <Search className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900">
                  No properties matching &ldquo;{searchQuery.trim()}&rdquo;
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  No commercial listings matched your search. Try searching by shop, office, plaza, warehouse, or city.
                </p>
              </div>
              <button
                onClick={() => setSearchQuery('')}
                className="px-4 py-2 rounded-[12px] bg-[#FF6B00] text-white text-xs font-bold hover:bg-[#E55F00] transition-colors shadow-xs"
              >
                Reset Search
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {searchResults.map((property) => (
                <PropertyCard
                  key={property.id}
                  property={property}
                  onClick={onSelectProperty}
                />
              ))}
            </div>
          )}
        </section>
      ) : marketplaceProperties.length === 0 ? (
        <section className="bg-white rounded-[24px] border border-slate-100 shadow-xs p-8 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-[#FFF5EE] text-[#FF6B00] mx-auto flex items-center justify-center shadow-xs">
            <Store className="w-7 h-7" />
          </div>
          <div className="space-y-1 max-w-md mx-auto">
            <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">
              No properties available yet.
            </h3>
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              There are currently no commercial spaces listed in the marketplace. Be the first to publish a verified commercial listing!
            </p>
          </div>
          {onNavigateToAdd && (
            <button
              onClick={onNavigateToAdd}
              className="px-5 py-2.5 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold shadow-md shadow-[#FF6B00]/25 active:scale-95 transition-all"
            >
              List Commercial Property
            </button>
          )}
        </section>
      ) : (
        <>
          {/* 2. Featured Commercial Properties */}
          {featuredProperties.length > 0 && (
            <section>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-md bg-amber-100 text-amber-600 flex items-center justify-center">
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                  <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                    Featured Properties
                  </h2>
                </div>
                <button
                  onClick={() => onNavigateToExplore()}
                  className="text-xs font-bold text-[#FF6B00] hover:text-[#E55F00] flex items-center gap-0.5"
                >
                  <span>See All</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex items-stretch gap-4 overflow-x-auto no-scrollbar pb-3 pt-1 -mx-4 px-4">
                {featuredProperties.map((property) => (
                  <PropertyCard
                    key={property.id}
                    property={property}
                    onClick={onSelectProperty}
                    horizontal
                  />
                ))}
              </div>
            </section>
          )}

          {/* 3. Latest Commercial Additions */}
          {latestProperties.length > 0 && (
            <section>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-md bg-blue-100 text-blue-600 flex items-center justify-center">
                    <Clock className="w-3.5 h-3.5" />
                  </div>
                  <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                    Latest Commercial Spaces
                  </h2>
                </div>
                <button
                  onClick={() => onNavigateToExplore()}
                  className="text-xs font-bold text-[#FF6B00] hover:text-[#E55F00] flex items-center gap-0.5"
                >
                  <span>See All</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex items-stretch gap-4 overflow-x-auto no-scrollbar pb-3 pt-1 -mx-4 px-4">
                {latestProperties.slice(0, 6).map((property) => (
                  <PropertyCard
                    key={property.id}
                    property={property}
                    onClick={onSelectProperty}
                    horizontal
                  />
                ))}
              </div>
            </section>
          )}

          {/* 4. Nearby Properties Section */}
          {nearbyProperties.length > 0 && (
            <section>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-md bg-emerald-100 text-emerald-600 flex items-center justify-center">
                    <Compass className="w-3.5 h-3.5" />
                  </div>
                  <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                    Nearby Prime Hubs
                  </h2>
                </div>
                <button
                  onClick={() => onNavigateToExplore()}
                  className="text-xs font-bold text-[#FF6B00] hover:text-[#E55F00] flex items-center gap-0.5"
                >
                  <span>See All</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex items-stretch gap-4 overflow-x-auto no-scrollbar pb-3 pt-1 -mx-4 px-4">
                {nearbyProperties.map((property) => (
                  <PropertyCard
                    key={property.id}
                    property={property}
                    onClick={onSelectProperty}
                    horizontal
                  />
                ))}
              </div>
            </section>
          )}

          {/* 5. Recommended Properties Grid */}
          {recommendedProperties.length > 0 && (
            <section>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-md bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center">
                    <TrendingUp className="w-3.5 h-3.5" />
                  </div>
                  <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                    Recommended for Your Business
                  </h2>
                </div>
                <span className="text-xs font-semibold text-slate-400">
                  {recommendedProperties.length} spaces
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {recommendedProperties.map((property) => (
                  <PropertyCard
                    key={property.id}
                    property={property}
                    onClick={onSelectProperty}
                  />
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </div>
  );
};
