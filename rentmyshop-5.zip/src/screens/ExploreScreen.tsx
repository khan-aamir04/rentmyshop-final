/**
 * RentMyShop Explore Screen
 * Search bar, filters, Map / List toggle, commercial category chips,
 * and responsive search results with empty and loading states.
 */
import React, { useState } from 'react';
import { useProperties } from '../context/PropertyContext';
import { PropertyModel, PropertyCategory } from '../types';
import { PropertyCard } from '../components/common/PropertyCard';
import { FilterSheet } from '../components/explore/FilterSheet';
import { MapView } from '../components/explore/MapView';
import { EmptyState } from '../components/common/EmptyState';
import { PropertyListSkeleton } from '../components/common/Skeletons';
import { 
  Search, 
  SlidersHorizontal, 
  List, 
  Map as MapIcon, 
  X,
  Store,
  RotateCcw
} from 'lucide-react';

interface ExploreScreenProps {
  onSelectProperty: (property: PropertyModel) => void;
  onNavigateToAdd?: () => void;
}

const QUICK_CATEGORIES: (PropertyCategory | 'all')[] = [
  'all',
  'Shops',
  'Offices',
  'Warehouses',
  'Commercial Plaza',
  'Kiosk',
  'Commercial Plot',
];

export const ExploreScreen: React.FC<ExploreScreenProps> = ({ onSelectProperty, onNavigateToAdd }) => {
  const {
    properties,
    filteredProperties,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    filterState,
    resetFilters,
    isLoading,
  } = useProperties();

  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Calculate active filter count
  let activeFilterCount = 0;
  if (filterState.purpose && filterState.purpose !== 'all') activeFilterCount++;
  if (filterState.category && filterState.category !== 'all') activeFilterCount++;
  if (filterState.city && filterState.city !== 'all' && filterState.city !== 'All Cities') activeFilterCount++;
  if (filterState.minPrice !== undefined || filterState.maxPrice !== undefined) activeFilterCount++;
  if (filterState.minArea !== undefined || filterState.maxArea !== undefined) activeFilterCount++;
  if (filterState.facilities && filterState.facilities.length > 0) activeFilterCount += filterState.facilities.length;
  if (filterState.sortBy && filterState.sortBy !== 'newest') activeFilterCount++;

  return (
    <div className="pb-28 pt-2 px-4 max-w-7xl mx-auto space-y-4 animate-in fade-in duration-300">
      {/* Top Search & Controls Header */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          {/* Search Input Field */}
          <div className="relative flex-1 flex items-center bg-white rounded-[14px] px-3.5 py-2.5 border border-slate-200 shadow-xs focus-within:border-[#FF6B00] focus-within:ring-2 focus-within:ring-[#FF6B00]/10 transition-all">
            <Search className="w-4.5 h-4.5 text-slate-400 mr-2 shrink-0" />
            <input
              type="text"
              placeholder="Search by city, title, or address in Pakistan..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-xs font-semibold text-slate-800 placeholder-slate-400 outline-hidden"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filter Button */}
          <button
            onClick={() => setIsFilterOpen(true)}
            aria-label="Open filters"
            className="relative px-3.5 py-2.5 rounded-[14px] bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors shrink-0"
          >
            <SlidersHorizontal className="w-4 h-4 text-[#FF6B00]" />
            <span className="hidden sm:inline">Filters</span>
            {activeFilterCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-[#FF6B00] text-white text-[10px] font-extrabold flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </button>

          {/* Map / List View Toggle */}
          <div className="bg-slate-100 p-1 rounded-[14px] flex items-center shrink-0 border border-slate-200/80">
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-[10px] text-xs font-bold transition-all ${
                viewMode === 'list'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`p-2 rounded-[10px] text-xs font-bold transition-all ${
                viewMode === 'map'
                  ? 'bg-white text-[#FF6B00] shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              title="Map View"
            >
              <MapIcon className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Category Chips Bar */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 -mx-4 px-4">
          {QUICK_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all border ${
                selectedCategory === cat
                  ? 'bg-[#FF6B00] text-white border-[#FF6B00] shadow-sm shadow-[#FF6B00]/25'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {cat === 'all' ? 'All Spaces' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Results Header Info */}
      <div className="flex items-center justify-between pt-1">
        <p className="text-xs font-bold text-slate-500">
          Showing <span className="text-slate-900 font-extrabold">{filteredProperties.length}</span> commercial properties
        </p>
        {activeFilterCount > 0 && (
          <button
            onClick={resetFilters}
            className="flex items-center gap-1 text-xs font-semibold text-[#FF6B00] hover:underline"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset filters</span>
          </button>
        )}
      </div>

      {/* Content Rendering: Map or List */}
      {viewMode === 'map' ? (
        <MapView
          properties={filteredProperties}
          onSelectProperty={onSelectProperty}
        />
      ) : (
        <div>
          {isLoading ? (
            <PropertyListSkeleton count={6} />
          ) : filteredProperties.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredProperties.map((property) => (
                <PropertyCard
                  key={property.id}
                  property={property}
                  onClick={onSelectProperty}
                />
              ))}
            </div>
          ) : properties.filter((p) => !p.isDeleted).length === 0 ? (
            <EmptyState
              icon={Store}
              title="No properties available yet."
              description="There are currently no commercial spaces listed in the marketplace. Be the first to publish a property!"
              actionLabel={onNavigateToAdd ? "List Commercial Property" : undefined}
              onAction={onNavigateToAdd}
            />
          ) : (
            <EmptyState
              icon={Store}
              title="No commercial spaces found"
              description="Try adjusting your category, price range, city, or facilities filters to discover available properties."
              actionLabel="Reset All Filters"
              onAction={resetFilters}
            />
          )}
        </div>
      )}

      {/* Filter Bottom Sheet */}
      <FilterSheet
        isOpen={isFilterOpen}
        onClose={() => setIsFilterOpen(false)}
      />
    </div>
  );
};
