/**
 * RentMyShop Splash Screen
 * Centered orange shop brand, "Find. Rent. Grow." tagline, smooth entrance
 */
import React, { useEffect } from 'react';
import { Store } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 1800);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-center p-6 select-none animate-in fade-in duration-300">
      {/* Brand Icon inside rounded square */}
      <div className="w-24 h-24 rounded-[26px] bg-[#FF6B00] flex items-center justify-center text-white shadow-2xl shadow-[#FF6B00]/40 ring-8 ring-[#FF6B00]/10 mb-6 animate-in zoom-in-75 duration-500">
        <Store className="w-12 h-12 stroke-[2.2]" />
      </div>

      {/* Brand Title */}
      <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight mb-2">
        Rent<span className="text-[#FF6B00]">My</span>Shop
      </h1>

      {/* Tagline */}
      <p className="text-sm font-semibold tracking-wide text-slate-400">
        Find. Rent. Grow.
      </p>

      {/* Subtle Loading Pulse */}
      <div className="absolute bottom-12 flex items-center gap-1.5">
        <span className="w-2 h-2 rounded-full bg-[#FF6B00] animate-ping" />
        <span className="text-xs font-semibold text-slate-400">Loading Marketplace...</span>
      </div>
    </div>
  );
};
