/**
 * RentMyShop Property Details Screen
 * Image carousel, commercial specifications, expandable description,
 * facility cards, Google Maps card, verified owner section, and sticky Chat CTA.
 * STRICT RULE: No phone numbers, no WhatsApp, exclusively in-app Chat with Owner.
 */
import React, { useState } from 'react';
import { PropertyModel, FacilityType } from '../types';
import { ImageCarousel } from '../components/property/ImageCarousel';
import { useChat } from '../context/ChatContext';
import { useProperties } from '../context/PropertyContext';
import { useAuth } from '../context/AuthContext';
import { LocationService } from '../services/locationService';
import { 
  MapPin, 
  ShieldCheck, 
  MessageSquare, 
  ExternalLink,
  Car,
  Bath,
  Zap,
  Droplets,
  Shield,
  Wifi,
  CornerDownRight,
  Flag,
  CheckCircle2,
  AlertTriangle,
  User as UserIcon
} from 'lucide-react';

interface PropertyDetailsScreenProps {
  property: PropertyModel;
  onBack: () => void;
  onOpenChat: (conversationId: string) => void;
}

const FACILITY_ICONS: Record<FacilityType, React.ReactNode> = {
  Parking: <Car className="w-5 h-5 text-[#FF6B00]" />,
  Washroom: <Bath className="w-5 h-5 text-[#FF6B00]" />,
  Electricity: <Zap className="w-5 h-5 text-[#FF6B00]" />,
  Water: <Droplets className="w-5 h-5 text-[#FF6B00]" />,
  Security: <Shield className="w-5 h-5 text-[#FF6B00]" />,
  Internet: <Wifi className="w-5 h-5 text-[#FF6B00]" />,
  Corner: <CornerDownRight className="w-5 h-5 text-[#FF6B00]" />,
};

export const PropertyDetailsScreen: React.FC<PropertyDetailsScreenProps> = ({
  property,
  onBack,
  onOpenChat,
}) => {
  const { openOrCreateConversation } = useChat();
  const { reportListing } = useProperties();
  const { currentUser } = useAuth();
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('Incorrect Information');
  const [reportDetails, setReportDetails] = useState('');
  const [reportSubmitted, setReportSubmitted] = useState(false);

  const ownerId = (property.ownerId || (property as any).userId || (property as any).uid || (property as any).sellerId || '').trim();
  const currentUid = (currentUser?.uid || '').trim();
  const isOwner = Boolean(currentUid && ownerId && currentUid === ownerId);

  const priceNum = property.price || 0;
  const formattedPrice = priceNum >= 1000
    ? `PKR ${priceNum.toLocaleString()}`
    : `PKR ${priceNum}`;

  const handleStartChat = () => {
    const convId = openOrCreateConversation(property);
    if (convId) {
      onOpenChat(convId);
    }
  };

  const handleSendReport = async (e: React.FormEvent) => {
    e.preventDefault();
    await reportListing(property.id, property.title, reportReason, reportDetails);
    setReportSubmitted(true);
    setTimeout(() => {
      setReportSubmitted(false);
      setShowReportModal(false);
    }, 2000);
  };

  const hasValidCoords = LocationService.isValidCoordinates(property.latitude, property.longitude);
  const mapsUrl = hasValidCoords ? LocationService.getGoogleMapsUrl(property.latitude, property.longitude) : '';

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-32 animate-in fade-in duration-300">
      {/* Top Image Carousel */}
      <ImageCarousel
        images={property.images || []}
        propertyId={property.id}
        propertyTitle={property.title}
        onBack={onBack}
      />

      {/* Main Container */}
      <div className="max-w-4xl mx-auto px-4 pt-5 space-y-6">
        {/* Header Block: Title, Price & Badges */}
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Price Badge */}
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                {formattedPrice}
              </span>
              {property.purpose === 'rent' && (
                <span className="text-sm font-bold text-slate-500">
                  {property.pricePeriod || '/month'}
                </span>
              )}
            </div>

            {/* Purpose & Verified Badges */}
            <div className="flex items-center gap-2">
              <span
                className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-xs ${
                  property.purpose === 'rent' ? 'bg-[#FF6B00]' : 'bg-emerald-600'
                }`}
              >
                For {property.purpose}
              </span>
              {property.isVerified && (
                <span className="flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Verified Listing
                </span>
              )}
            </div>
          </div>

          {/* Title */}
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight leading-snug">
            {property.title}
          </h1>

          {/* Location Pin */}
          <p className="flex items-center gap-2 text-xs sm:text-sm text-slate-600 font-medium">
            <MapPin className="w-4 h-4 text-[#FF6B00] shrink-0" />
            <span>{property.address}, {property.city}</span>
          </p>

          {/* Core Specs Ribbon */}
          <div className="grid grid-cols-3 gap-3 pt-3 border-t border-slate-100 text-center">
            <div className="p-2.5 rounded-[14px] bg-slate-50">
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Category</p>
              <p className="text-xs sm:text-sm font-bold text-slate-800 mt-0.5">{property.category}</p>
            </div>
            <div className="p-2.5 rounded-[14px] bg-slate-50">
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Area</p>
              <p className="text-xs sm:text-sm font-bold text-slate-800 mt-0.5">{(property.area || 0).toLocaleString()} sq ft</p>
            </div>
            <div className="p-2.5 rounded-[14px] bg-slate-50">
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Engagement</p>
              <p className="text-xs sm:text-sm font-bold text-slate-800 mt-0.5">{property.views || 0} views</p>
            </div>
          </div>
        </div>

        {/* Commercial Property Description */}
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-3">
          <h2 className="text-base font-extrabold text-slate-900">About this Commercial Space</h2>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
            {isDescriptionExpanded
              ? property.description
              : `${(property.description || '').slice(0, 220)}...`}
          </p>
          {(property.description || '').length > 220 && (
            <button
              onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
              className="text-xs font-bold text-[#FF6B00] hover:underline pt-1"
            >
              {isDescriptionExpanded ? 'Read Less' : 'Read More'}
            </button>
          )}
        </div>

        {/* Facilities & Amenities */}
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-4">
          <h2 className="text-base font-extrabold text-slate-900">Commercial Amenities & Facilities</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {(property.facilities || []).map((fac) => (
              <div
                key={fac}
                className="flex items-center gap-2.5 p-3 rounded-[16px] bg-slate-50 border border-slate-100 text-slate-800"
              >
                <div className="w-8 h-8 rounded-[10px] bg-[#FFF5EE] flex items-center justify-center shrink-0">
                  {FACILITY_ICONS[fac] || <CheckCircle2 className="w-4 h-4 text-[#FF6B00]" />}
                </div>
                <span className="text-xs font-bold">{fac}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Map Location Card */}
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-extrabold text-slate-900">Commercial Location</h2>
            {hasValidCoords && (
              <a
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-xs font-bold text-[#FF6B00] hover:underline"
              >
                <span>Open in Google Maps</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>

          <div className="relative aspect-[16/8] w-full rounded-[18px] bg-slate-100 overflow-hidden border border-slate-200 flex items-center justify-center">
            <div className="absolute inset-0 bg-[#E8EEF5] flex items-center justify-center opacity-70">
              <div className="w-full h-full bg-[radial-gradient(#94a3b8_1px,transparent_1px)] [background-size:16px_16px]" />
            </div>
            <div className="relative z-10 flex flex-col items-center gap-1 text-center p-4">
              <div className="w-10 h-10 rounded-full bg-[#FF6B00] text-white flex items-center justify-center shadow-lg shadow-[#FF6B00]/40 ring-4 ring-white animate-bounce">
                <MapPin className="w-5 h-5" />
              </div>
              <p className="text-xs font-bold text-slate-900 bg-white/95 px-3 py-1 rounded-full shadow-xs mt-1">
                {property.address}, {property.city}
              </p>
              {hasValidCoords ? (
                <span className="text-[11px] font-semibold text-slate-500">
                  Coordinates: {Number(property.latitude).toFixed(4)}, {Number(property.longitude).toFixed(4)}
                </span>
              ) : (
                <span className="text-[11px] font-semibold text-slate-500">
                  {property.city || 'Commercial Location'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Owner Information Card (STRICT: NO phone, NO WhatsApp, only verified owner info) */}
        <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-full overflow-hidden ring-2 ring-[#FF6B00]/20 bg-slate-100 shrink-0 flex items-center justify-center">
              {property.ownerImage ? (
                <img
                  src={property.ownerImage}
                  alt={property.ownerName || 'Property Owner'}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center font-bold text-lg">
                  {property.ownerName ? property.ownerName.charAt(0).toUpperCase() : <UserIcon className="w-6 h-6" />}
                </div>
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-bold text-slate-900">{property.ownerName || 'Property Owner'}</h3>
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-xs text-slate-500 font-medium">Verified Commercial Partner</p>
              <p className="text-[11px] font-semibold text-emerald-600 mt-0.5">Typically responds within 1 hour</p>
            </div>
          </div>

          <button
            onClick={() => setShowReportModal(true)}
            className="text-slate-400 hover:text-rose-500 p-2 text-xs font-semibold flex items-center gap-1 transition-colors"
            title="Report this listing"
          >
            <Flag className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Report</span>
          </button>
        </div>
      </div>

      {/* Sticky Bottom Floating CTA: Chat with Owner */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/80 p-4 safe-area-pb">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Total Price</span>
            <span className="text-xl font-extrabold text-slate-900">
              {formattedPrice}
              {property.purpose === 'rent' && (
                <span className="text-xs font-bold text-slate-500"> {property.pricePeriod || '/mo'}</span>
              )}
            </span>
          </div>
          {!isOwner && (
            <button
              id="chat-with-owner-cta"
              onClick={handleStartChat}
              className="flex-1 max-w-xs py-3.5 px-6 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#FF6B00]/30 active:scale-98 transition-all flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Chat with Owner</span>
            </button>
          )}
        </div>
      </div>

      {/* Report Listing Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-[24px] p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center gap-2 text-rose-600">
              <AlertTriangle className="w-5 h-5" />
              <h3 className="text-base font-bold text-slate-900">Report Listing</h3>
            </div>
            <p className="text-xs text-slate-500">
              Help maintain a trusted marketplace. What issue did you encounter with this property?
            </p>

            {reportSubmitted ? (
              <div className="p-4 bg-emerald-50 rounded-[14px] text-emerald-800 text-xs font-bold text-center">
                Thank you. Your report has been submitted to the moderation team.
              </div>
            ) : (
              <form onSubmit={handleSendReport} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Reason</label>
                  <select
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value)}
                    className="w-full p-2.5 rounded-[12px] bg-slate-50 border border-slate-200 text-xs font-semibold"
                  >
                    <option value="Incorrect Information">Incorrect Information</option>
                    <option value="Fraud / Suspicious Listing">Fraud / Suspicious Listing</option>
                    <option value="Wrong Category">Wrong Category</option>
                    <option value="Inappropriate Content">Inappropriate Content</option>
                    <option value="Property Unavailable">Property Already Rented/Sold</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Details</label>
                  <textarea
                    rows={3}
                    required
                    value={reportDetails}
                    onChange={(e) => setReportDetails(e.target.value)}
                    placeholder="Provide specific details for the moderation review..."
                    className="w-full p-2.5 rounded-[12px] bg-slate-50 border border-slate-200 text-xs font-medium"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowReportModal(false)}
                    className="px-4 py-2 rounded-[12px] bg-slate-100 text-slate-600 text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-[12px] bg-rose-600 text-white text-xs font-bold shadow-md shadow-rose-600/20 hover:bg-rose-700"
                  >
                    Submit Report
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
