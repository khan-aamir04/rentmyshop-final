/**
 * RentMyShop My Listings Screen
 * Commercial property management: Edit, Pause/Activate, Mark Rented, Mark Sold, Delete.
 * Metrics: Views, Favorites, Chats.
 */
import React, { useState } from 'react';
import { useProperties } from '../context/PropertyContext';
import { PropertyModel, PropertyStatus } from '../types';
import { 
  Plus, 
  Store, 
  Eye, 
  Heart, 
  MessageSquare, 
  MoreVertical, 
  Play, 
  Pause, 
  CheckCircle, 
  DollarSign, 
  Trash2, 
  MapPin 
} from 'lucide-react';
import { EmptyState } from '../components/common/EmptyState';

interface MyListingsScreenProps {
  onSelectProperty: (property: PropertyModel) => void;
  onNavigateToAddListing: () => void;
  onEditListing?: (property: PropertyModel) => void;
}

export const MyListingsScreen: React.FC<MyListingsScreenProps> = ({
  onSelectProperty,
  onNavigateToAddListing,
}) => {
  const { myListings, updateListingStatus, deleteListing } = useProperties();
  const [activeTab, setActiveTab] = useState<PropertyStatus | 'all'>('all');
  const [actionMenuOpenId, setActionMenuOpenId] = useState<string | null>(null);

  const filtered = myListings.filter((p) => {
    if (activeTab === 'all') return true;
    return p.status === activeTab;
  });

  const getStatusBadge = (status: PropertyStatus) => {
    switch (status) {
      case 'active':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-100 text-emerald-700">Active</span>;
      case 'paused':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-amber-100 text-amber-700">Paused</span>;
      case 'rented':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-blue-100 text-blue-700">Rented</span>;
      case 'sold':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-purple-100 text-purple-700">Sold</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-slate-100 text-slate-700">{status}</span>;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-28 pt-4 px-4 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            My Commercial Listings
          </h1>
          <p className="text-xs text-slate-500 font-medium">
            Manage your commercial portfolio, availability, and tenant inquiries
          </p>
        </div>
        <button
          onClick={onNavigateToAddListing}
          className="px-4 py-2.5 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-[#FF6B00]/25 active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Listing</span>
        </button>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 -mx-4 px-4">
        {[
          { id: 'all', label: 'All Listings' },
          { id: 'active', label: 'Active' },
          { id: 'paused', label: 'Paused' },
          { id: 'rented', label: 'Rented' },
          { id: 'sold', label: 'Sold' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold capitalize transition-all border whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-[#FF6B00] text-white border-[#FF6B00] shadow-xs'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Listings List */}
      {filtered.length > 0 ? (
        <div className="space-y-4">
          {filtered.map((property) => (
            <div
              key={property.id}
              className="bg-white rounded-[20px] p-4 border border-slate-100 shadow-xs hover:shadow-md transition-shadow relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
            >
              {/* Image & Main Info */}
              <div 
                onClick={() => onSelectProperty(property)}
                className="flex items-start sm:items-center gap-3.5 cursor-pointer flex-1"
              >
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-[14px] overflow-hidden bg-slate-100 shrink-0">
                  <img
                    src={property.thumbnail || property.images?.[0] || 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400'}
                    alt={property.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    {getStatusBadge(property.status)}
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      {property.category}
                    </span>
                  </div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 line-clamp-1 hover:text-[#FF6B00] transition-colors">
                    {property.title}
                  </h3>
                  <p className="text-xs text-slate-500 flex items-center gap-1 line-clamp-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{property.address}, {property.city}</span>
                  </p>
                  <div className="flex items-baseline gap-1 text-sm font-extrabold text-[#FF6B00] pt-0.5">
                    PKR {(property.price || 0).toLocaleString()}
                    {property.purpose === 'rent' && (
                      <span className="text-[11px] font-semibold text-slate-400">/mo</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Engagement Stats: Views, Favorites, Chats */}
              <div className="flex items-center gap-4 sm:gap-6 px-3 py-2 bg-slate-50 rounded-[14px] self-stretch sm:self-auto justify-around sm:justify-start text-xs font-bold text-slate-600">
                <div className="flex items-center gap-1.5" title="Total Views">
                  <Eye className="w-4 h-4 text-slate-400" />
                  <span>{property.views || 0}</span>
                </div>
                <div className="flex items-center gap-1.5" title="Favorites">
                  <Heart className="w-4 h-4 text-rose-500" />
                  <span>{property.favorites || 0}</span>
                </div>
                <div className="flex items-center gap-1.5" title="Chat Inquiries">
                  <MessageSquare className="w-4 h-4 text-[#FF6B00]" />
                  <span>{property.chatCount || 0}</span>
                </div>
              </div>

              {/* Actions Dropdown Button */}
              <div className="relative self-end sm:self-center">
                <button
                  onClick={() =>
                    setActionMenuOpenId(actionMenuOpenId === property.id ? null : property.id)
                  }
                  className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>

                {actionMenuOpenId === property.id && (
                  <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-[16px] shadow-2xl border border-slate-100 p-1.5 z-30 animate-in fade-in zoom-in-95">
                    {/* Toggle Pause / Resume */}
                    {property.status === 'active' ? (
                      <button
                        onClick={() => {
                          updateListingStatus(property.id, 'paused');
                          setActionMenuOpenId(null);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-amber-700 hover:bg-amber-50 rounded-[10px] transition-colors"
                      >
                        <Pause className="w-3.5 h-3.5" />
                        <span>Pause Listing</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          updateListingStatus(property.id, 'active');
                          setActionMenuOpenId(null);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-emerald-700 hover:bg-emerald-50 rounded-[10px] transition-colors"
                      >
                        <Play className="w-3.5 h-3.5" />
                        <span>Activate Listing</span>
                      </button>
                    )}

                    {/* Mark Rented */}
                    <button
                      onClick={() => {
                        updateListingStatus(property.id, 'rented');
                        setActionMenuOpenId(null);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-50 rounded-[10px] transition-colors"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Mark as Rented</span>
                    </button>

                    {/* Mark Sold */}
                    <button
                      onClick={() => {
                        updateListingStatus(property.id, 'sold');
                        setActionMenuOpenId(null);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-purple-700 hover:bg-purple-50 rounded-[10px] transition-colors"
                    >
                      <DollarSign className="w-3.5 h-3.5" />
                      <span>Mark as Sold</span>
                    </button>

                    <div className="h-px bg-slate-100 my-1" />

                    {/* Soft Delete */}
                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to remove "${property.title}"?`)) {
                          deleteListing(property.id);
                        }
                        setActionMenuOpenId(null);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-[10px] transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete Listing</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Store}
          title="No listings in this view"
          description="Create a listing to connect with commercial tenants, business owners, and corporate buyers across Pakistan."
          actionLabel="Create Property Listing"
          onAction={onNavigateToAddListing}
        />
      )}
    </div>
  );
};
