/**
 * RentMyShop In-App Chat List Screen
 * Displays active conversations with commercial owners, latest message, unread indicators
 */
import React, { useState, useRef } from 'react';
import { useChat } from '../context/ChatContext';
import { useAuth } from '../context/AuthContext';
import { ConversationModel } from '../types';
import { Search, MessageSquare, Store, ArrowRight, User as UserIcon, Trash2, AlertTriangle, Loader2 } from 'lucide-react';

interface ChatListScreenProps {
  onOpenConversation: (conversationId: string) => void;
  onNavigateToExplore: () => void;
}

export const ChatListScreen: React.FC<ChatListScreenProps> = ({
  onOpenConversation,
  onNavigateToExplore,
}) => {
  const { conversations, deleteConversation } = useChat();
  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedConvForMenu, setSelectedConvForMenu] = useState<ConversationModel | null>(null);
  const [convToDelete, setConvToDelete] = useState<ConversationModel | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const longPressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const touchStartPosRef = useRef<{ x: number; y: number } | null>(null);
  const isLongPressTriggeredRef = useRef<boolean>(false);

  const handleStartPress = (conv: ConversationModel) => {
    isLongPressTriggeredRef.current = false;
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
    }
    longPressTimerRef.current = setTimeout(() => {
      isLongPressTriggeredRef.current = true;
      setSelectedConvForMenu(conv);
    }, 500);
  };

  const handleCancelPress = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handleConfirmDelete = async () => {
    if (!convToDelete || isDeleting) return;
    setIsDeleting(true);
    setDeleteError(null);
    try {
      await deleteConversation(convToDelete.id);
      setConvToDelete(null);
    } catch (err: any) {
      console.error('[RentMyShop] Delete conversation failed:', err);
      setDeleteError(err?.message || 'Failed to delete chat. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  const filtered = conversations.filter((c) => {
    const query = searchQuery.toLowerCase();
    const title = (c.shopTitle || c.propertyTitle || '').toLowerCase();
    const names = c.participantNames ? Object.values(c.participantNames).join(' ').toLowerCase() : '';
    return title.includes(query) || names.includes(query);
  });

  const formatTime = (timeStr?: string) => {
    if (!timeStr) return '';
    return timeStr;
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-28 pt-4 px-4 max-w-3xl mx-auto space-y-4 animate-in fade-in duration-300">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
          Commercial Messages
        </h1>
        <p className="text-xs text-slate-500 font-medium">
          Direct, private communications with commercial property partners
        </p>
      </div>

      {/* Search Conversations */}
      <div className="relative flex items-center bg-white rounded-[14px] px-3.5 py-2.5 border border-slate-200 shadow-xs focus-within:border-[#FF6B00]">
        <Search className="w-4 h-4 text-slate-400 mr-2 shrink-0" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by partner or property title..."
          className="w-full bg-transparent text-xs font-semibold text-slate-800 placeholder-slate-400 outline-hidden"
        />
      </div>

      {/* Conversations List */}
      {filtered.length > 0 ? (
        <div className="bg-white rounded-[24px] border border-slate-100 shadow-xs divide-y divide-slate-100 overflow-hidden">
          {filtered.map((conv) => {
            const otherId = conv.participants.find((p) => p !== currentUser?.uid) || '';
            const otherName = (conv.participantNames && conv.participantNames[otherId]) || 'Commercial Partner';
            const otherImage = (conv.participantAvatars && conv.participantAvatars[otherId]) || '';
            const unread = conv.unreadCount || 0;
            const pTitle = conv.shopTitle || conv.propertyTitle || 'Commercial Listing';

            return (
              <div
                key={conv.id}
                id={`chat-item-${conv.id}`}
                onTouchStart={(e) => {
                  const touch = e.touches[0];
                  touchStartPosRef.current = { x: touch.clientX, y: touch.clientY };
                  handleStartPress(conv);
                }}
                onTouchMove={(e) => {
                  if (touchStartPosRef.current && e.touches[0]) {
                    const touch = e.touches[0];
                    const deltaX = Math.abs(touch.clientX - touchStartPosRef.current.x);
                    const deltaY = Math.abs(touch.clientY - touchStartPosRef.current.y);
                    if (deltaX > 10 || deltaY > 10) {
                      handleCancelPress();
                    }
                  }
                }}
                onTouchEnd={() => {
                  handleCancelPress();
                }}
                onTouchCancel={() => {
                  handleCancelPress();
                }}
                onMouseDown={(e) => {
                  if (e.button === 0) {
                    handleStartPress(conv);
                  }
                }}
                onMouseUp={() => {
                  handleCancelPress();
                }}
                onMouseLeave={() => {
                  handleCancelPress();
                }}
                onContextMenu={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  handleCancelPress();
                  isLongPressTriggeredRef.current = true;
                  setSelectedConvForMenu(conv);
                }}
                onClick={() => {
                  if (isLongPressTriggeredRef.current) {
                    isLongPressTriggeredRef.current = false;
                    return;
                  }
                  onOpenConversation(conv.id);
                }}
                className="p-4 flex items-center gap-3.5 hover:bg-slate-50 cursor-pointer transition-colors relative select-none"
              >
                {/* Avatar with unread dot indicator */}
                <div className="relative shrink-0">
                  <div className="w-13 h-13 rounded-full overflow-hidden bg-slate-100 ring-2 ring-slate-100 flex items-center justify-center">
                    {otherImage ? (
                      <img
                        src={otherImage}
                        alt={otherName}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center font-bold text-sm">
                        {otherName ? otherName.charAt(0).toUpperCase() : <UserIcon className="w-5 h-5" />}
                      </div>
                    )}
                  </div>
                  {unread > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#FF6B00] text-white text-[9px] font-extrabold flex items-center justify-center ring-2 ring-white">
                      {unread}
                    </span>
                  )}
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="text-sm font-bold text-slate-900 truncate">
                      {otherName}
                    </h3>
                    <span className="text-[10px] font-semibold text-slate-400">
                      {formatTime(conv.lastMessageTime || conv.lastMessageTimestamp)}
                    </span>
                  </div>

                  {/* Property mini ribbon */}
                  <div className="flex items-center gap-1 text-[11px] font-bold text-[#FF6B00] mb-1 truncate">
                    <Store className="w-3 h-3 shrink-0" />
                    <span className="truncate">{pTitle}</span>
                  </div>

                  {/* Last Message preview */}
                  <p className="text-xs text-slate-500 truncate font-medium">
                    {conv.lastMessage || 'Started conversation'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-[24px] border border-slate-100 p-8 text-center space-y-4 shadow-xs">
          <div className="w-14 h-14 rounded-full bg-[#FFF5EE] text-[#FF6B00] mx-auto flex items-center justify-center">
            <MessageSquare className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-slate-900">No conversations yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              Browse verified commercial shops, offices, and plots, then tap &quot;Chat with Owner&quot; to initiate a negotiation.
            </p>
          </div>
          <button
            onClick={onNavigateToExplore}
            className="px-5 py-2.5 rounded-[12px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold inline-flex items-center gap-2 shadow-md shadow-[#FF6B00]/20 active:scale-95 transition-all"
          >
            <span>Explore Properties</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Long-Press Action Menu */}
      {selectedConvForMenu && (
        <div
          id="chat-action-menu-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4 animate-in fade-in duration-150"
          onClick={() => setSelectedConvForMenu(null)}
        >
          <div
            id="chat-action-menu-modal"
            className="bg-white rounded-[20px] p-3 max-w-xs w-full shadow-2xl border border-slate-100 space-y-1.5 animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-3 py-2 border-b border-slate-100">
              <p className="text-xs font-bold text-slate-900 truncate">
                {(() => {
                  const otherId = selectedConvForMenu.participants.find((p) => p !== currentUser?.uid) || '';
                  return (
                    (selectedConvForMenu.participantNames && selectedConvForMenu.participantNames[otherId]) ||
                    'Commercial Partner'
                  );
                })()}
              </p>
              <p className="text-[10px] text-slate-400 truncate">
                {selectedConvForMenu.shopTitle || selectedConvForMenu.propertyTitle || 'Commercial Listing'}
              </p>
            </div>

            <button
              type="button"
              id="action-menu-delete-chat-btn"
              onClick={() => {
                setConvToDelete(selectedConvForMenu);
                setSelectedConvForMenu(null);
                setDeleteError(null);
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-[12px] text-xs font-bold text-rose-600 hover:bg-rose-50 transition-colors text-left cursor-pointer"
            >
              <Trash2 className="w-4 h-4 shrink-0" />
              <span>Delete Chat</span>
            </button>

            <button
              type="button"
              id="action-menu-cancel-btn"
              onClick={() => setSelectedConvForMenu(null)}
              className="w-full flex items-center justify-center px-3 py-2 rounded-[12px] text-xs font-semibold text-slate-500 hover:bg-slate-50 transition-colors text-center cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      {convToDelete && (
        <div
          id="chat-delete-confirm-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150"
          onClick={() => {
            if (!isDeleting) {
              setConvToDelete(null);
              setDeleteError(null);
            }
          }}
        >
          <div
            id="chat-delete-confirm-modal"
            className="bg-white rounded-[24px] p-6 max-w-sm w-full shadow-2xl border border-slate-100 space-y-4 animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900">Delete Chat</h3>
                <p className="text-xs text-slate-500 font-medium">Permanently remove conversation</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              Are you sure you want to permanently delete this chat? This conversation and its messages will be removed from your chat list.
            </p>

            {deleteError && (
              <div className="p-3 rounded-[12px] bg-rose-50 border border-rose-100 text-rose-700 text-xs font-semibold flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{deleteError}</span>
              </div>
            )}

            <div className="flex items-center gap-2.5 pt-1">
              <button
                type="button"
                id="delete-confirm-cancel-btn"
                disabled={isDeleting}
                onClick={() => {
                  setConvToDelete(null);
                  setDeleteError(null);
                }}
                className="flex-1 py-2.5 px-4 rounded-[12px] border border-slate-200 hover:bg-slate-50 text-xs font-bold text-slate-700 transition-colors disabled:opacity-50 cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                id="delete-confirm-delete-btn"
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 px-4 rounded-[12px] bg-rose-600 hover:bg-rose-700 text-xs font-bold text-white transition-colors flex items-center justify-center gap-1.5 shadow-md shadow-rose-600/20 disabled:opacity-50 cursor-pointer"
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <span>Delete</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

