/**
 * RentMyShop Profile Setup Screen
 * Mandatory profile image picker, full name, read-only email.
 * Ensures new users do NOT inherit another account's picture.
 */
import React, { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { ImageUploadService } from '../../services/imageUploadService';
import { 
  Camera, 
  User, 
  Mail, 
  ArrowRight, 
  AlertCircle 
} from 'lucide-react';

interface ProfileSetupScreenProps {
  onComplete: () => void;
}

export const ProfileSetupScreen: React.FC<ProfileSetupScreenProps> = ({ onComplete }) => {
  const { currentUser, completeProfileSetup, isLoading } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [fullName, setFullName] = useState(currentUser?.fullName || '');
  const [profileImage, setProfileImage] = useState<string>(currentUser?.profileImage || '');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    setUploading(true);
    try {
      const url = await ImageUploadService.uploadImage(file);
      setProfileImage(url);
    } catch {
      setError('Could not process photo. Please select another image.');
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      setError('Please provide your name or company designation.');
      return;
    }
    if (!profileImage) {
      setError('Profile picture is mandatory before continuing.');
      return;
    }

    await completeProfileSetup(fullName.trim(), profileImage);
    onComplete();
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="text-center text-2xl font-extrabold text-slate-900 tracking-tight">
          Complete Your Profile
        </h2>
        <p className="mt-1.5 text-center text-xs text-slate-500 font-medium">
          Set up your verified commercial identity before continuing
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 sm:px-10 rounded-[28px] border border-slate-100 shadow-xl shadow-slate-200/50">
          {error && (
            <div className="mb-5 p-3.5 rounded-[14px] bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-rose-700 text-xs font-medium">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Profile Picture Upload Avatar */}
            <div className="flex flex-col items-center">
              <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                <div className="w-28 h-28 rounded-full overflow-hidden ring-4 ring-[#FF6B00]/20 bg-slate-100 shadow-lg flex items-center justify-center">
                  {profileImage ? (
                    <img
                      src={profileImage}
                      alt="Profile Avatar"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full bg-[#FFF5EE] text-[#FF6B00] flex flex-col items-center justify-center">
                      <Camera className="w-8 h-8 mb-1" />
                      <span className="text-[10px] font-bold">Add Photo</span>
                    </div>
                  )}
                </div>
                <div className="absolute bottom-1 right-1 w-9 h-9 rounded-full bg-[#FF6B00] text-white flex items-center justify-center shadow-md ring-2 ring-white group-hover:bg-[#E55F00] transition-colors">
                  {uploading ? (
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Camera className="w-4 h-4" />
                  )}
                </div>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="hidden"
              />
              <p className="text-[11px] font-semibold text-slate-400 mt-2">
                Tap photo to change (Required)
              </p>
            </div>

            {/* Full Name */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Full Name / Business Representative
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Your Full Name"
                  className="w-full pl-10 pr-3.5 py-3 rounded-[14px] bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 focus:bg-white focus:border-[#FF6B00] outline-hidden transition-all"
                />
              </div>
            </div>

            {/* Email Address (Read-only) */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                Verified Email Address (Read Only)
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  readOnly
                  value={currentUser?.email || ''}
                  className="w-full pl-10 pr-3.5 py-3 rounded-[14px] bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-500 cursor-not-allowed outline-hidden"
                />
              </div>
            </div>

            {/* Submit Continue CTA */}
            <div className="pt-3">
              <button
                type="submit"
                disabled={isLoading || uploading}
                className="w-full py-3.5 rounded-[14px] bg-[#FF6B00] hover:bg-[#E55F00] text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#FF6B00]/25 active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isLoading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>Continue to Marketplace</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
