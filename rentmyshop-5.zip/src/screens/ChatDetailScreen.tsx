/**
 * RentMyShop In-App Chat Detail Screen
 * Real-time messaging between tenant/buyer and verified property owner.
 * Context-aware property banner, message bubbles, active typing indication.
 */
import React, { useState, useEffect, useRef } from 'react';
import { useChat } from '../context/ChatContext';
import { useAuth } from '../context/AuthContext';
import { MessageModel } from '../types';
import { firestoreInstance } from '../services/firebaseConfig';
import { doc, onSnapshot } from 'firebase/firestore';
import { 
  ArrowLeft, 
  Send, 
  ExternalLink, 
  CheckCheck, 
  ShieldCheck,
  User as UserIcon
} from 'lucide-react';

interface ChatDetailScreenProps {
  conversationId: string;
  onBack: () => void;
  onViewProperty: (propertyId: string) => void;
}

export const ChatDetailScreen: React.FC<ChatDetailScreenProps> = ({
  conversationId,
  onBack,
  onViewProperty,
}) => {
  const { 
    conversations, 
    activeMessages, 
    sendMessage, 
    markAsSeen, 
    selectConversation, 
    isTyping, 
    getMessagesForConversation,
    getDraftMessage,
    clearDraftMessage,
  } = useChat();
  const { currentUser } = useAuth();
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [otherUserDoc, setOtherUserDoc] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const sendingRef = useRef(false);

  // Sync conversation selection and prefill draft if any
  useEffect(() => {
    selectConversation(conversationId);
    markAsSeen(conversationId);
    const draft = getDraftMessage(conversationId);
    if (draft) {
      setInputText(draft);
      clearDraftMessage(conversationId);
    }
  }, [conversationId]);

  const conversation = conversations.find((c) => c.id === conversationId);
  const [directConv, setDirectConv] = useState<any>(null);

  // Fallback direct conversation listener if not yet populated in context list
  useEffect(() => {
    if (!conversation && conversationId && firestoreInstance) {
      const unsub = onSnapshot(
        doc(firestoreInstance, 'conversations', conversationId),
        (snap) => {
          if (snap.exists()) {
            setDirectConv({ id: snap.id, ...snap.data() });
          }
        },
        (err) => {
          console.warn('[RentMyShop] Error fetching direct conversation:', err);
        }
      );
      return () => unsub();
    }
  }, [conversation, conversationId]);

  const activeConv = conversation || directConv;
  const otherId = (() => {
    if (activeConv?.participants && Array.isArray(activeConv.participants)) {
      const found = activeConv.participants.find((p: string) => p && p.trim() !== currentUser?.uid?.trim());
      if (found) return found;
    }
    if (conversationId && conversationId.startsWith('conv_')) {
      const parts = conversationId.split('_');
      const candidates = parts.slice(-2);
      const found = candidates.find((u: string) => u && u.trim() !== currentUser?.uid?.trim());
      if (found) return found;
    }
    return '';
  })();

  // Listen to other user's real presence state from Firestore
  useEffect(() => {
    if (!otherId || !firestoreInstance) return;
    const unsub = onSnapshot(
      doc(firestoreInstance, 'users', otherId),
      (snap) => {
        if (snap.exists()) {
          setOtherUserDoc(snap.data());
        }
      },
      (err) => {
        console.warn('[RentMyShop] Error fetching other user presence:', err);
      }
    );
    return () => unsub();
  }, [otherId]);

  // Real presence calculation (within 3 minutes = online)
  const getPresence = () => {
    const lastSeenStr = otherUserDoc?.lastSeen || otherUserDoc?.lastLogin;
    if (!lastSeenStr) {
      return { isOnline: false, text: 'Offline' };
    }
    try {
      const diff = Date.now() - new Date(lastSeenStr).getTime();
      if (diff < 3 * 60 * 1000) {
        return { isOnline: true, text: 'Active now' };
      }
      const minutes = Math.floor(diff / 60000);
      if (minutes < 60) return { isOnline: false, text: `Last seen ${minutes}m ago` };
      const hours = Math.floor(minutes / 60);
      if (hours < 24) return { isOnline: false, text: `Last seen ${hours}h ago` };
      const days = Math.floor(hours / 24);
      if (days === 1) return { isOnline: false, text: 'Last seen yesterday' };
      if (days < 7) return { isOnline: false, text: `Last seen ${days}d ago` };
      return {
        isOnline: false,
        text: `Last seen ${new Date(lastSeenStr).toLocaleDateString([], { month: 'short', day: 'numeric' })}`,
      };
    } catch {
      return { isOnline: false, text: 'Offline' };
    }
  };

  const presence = getPresence();

  const conversationMessages = getMessagesForConversation(conversationId);
  const displayMessages = conversationMessages.length > 0 ? conversationMessages : activeMessages;

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [displayMessages, isTyping]);

  if (!activeConv) {
    return (
      <div className="flex flex-col h-screen bg-[#F8F9FA] items-center justify-center p-8 text-center text-slate-500">
        <div className="w-8 h-8 border-2 border-[#FF6B00] border-t-transparent rounded-full animate-spin mb-3" />
        <p className="text-xs font-semibold">Loading conversation...</p>
        <button onClick={onBack} className="mt-4 text-xs font-bold text-[#FF6B00]">
          Return to messages
        </button>
      </div>
    );
  }

  const otherName = (activeConv.participantNames && activeConv.participantNames[otherId]) || otherUserDoc?.fullName || 'Commercial Partner';
  const otherImage = (activeConv.participantAvatars && activeConv.participantAvatars[otherId]) || otherUserDoc?.profileImage || '';
  const propertyId = activeConv.shopId || activeConv.propertyId || '';
  const propertyTitle = activeConv.shopTitle || activeConv.propertyTitle || 'Commercial Property';
  const propertyThumbnail = activeConv.shopThumbnail || activeConv.propertyThumbnail || 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=400';
  const propertyPrice = activeConv.shopPrice || activeConv.propertyPrice || 0;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isSending || sendingRef.current) return;
    sendingRef.current = true;
    const textToSend = inputText.trim();
    setInputText('');
    setSendError(null);
    try {
      setIsSending(true);
      await sendMessage(conversationId, textToSend, otherId);
    } catch (err: any) {
      setInputText(textToSend);
      console.error('[RentMyShop Chat Error]', {
        code: err?.code,
        message: err?.message,
        conversationId,
      });
      const errorMsg = err?.code === 'permission-denied'
        ? 'Could not deliver message: Firebase permission-denied. Please publish Firestore Security Rules in Firebase Console.'
        : `Could not deliver message: ${err?.message || err?.code || 'Please check your connection and try again.'}`;
      setSendError(errorMsg);
    } finally {
      setIsSending(false);
      sendingRef.current = false;
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#F8F9FA] fixed inset-0 z-50 animate-in slide-in-from-right duration-300">
      {/* 1. Top Bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between shadow-2xs">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-100 ring-2 ring-slate-100 flex items-center justify-center">
                {otherImage ? (
                  <img
                    src={otherImage}
                    alt={otherName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center font-bold text-xs">
                    {otherName ? otherName.charAt(0).toUpperCase() : <UserIcon className="w-4 h-4" />}
                  </div>
                )}
              </div>
              <span
                className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-white ${
                  presence.isOnline ? 'bg-emerald-500' : 'bg-slate-300'
                }`}
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-extrabold text-slate-900">{otherName}</h2>
                <ShieldCheck className="w-3.5 h-3.5 text-[#FF6B00]" />
              </div>
              <p
                className={`text-[10px] font-semibold mt-0.5 ${
                  presence.isOnline ? 'text-emerald-600' : 'text-slate-400'
                }`}
              >
                {presence.text}
              </p>
            </div>
          </div>
        </div>

        {/* View Property Link */}
        {propertyId && (
          <button
            onClick={() => onViewProperty(propertyId)}
            className="flex items-center gap-1 text-xs font-bold text-[#FF6B00] hover:bg-[#FFF5EE] px-2.5 py-1.5 rounded-full transition-colors"
          >
            <span className="hidden sm:inline">Listing Details</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* 2. Property Mini Snapshot Banner */}
      {propertyId && (
        <div 
          onClick={() => onViewProperty(propertyId)}
          className="bg-[#FFF5EE] border-b border-[#FF6B00]/20 px-4 py-2.5 flex items-center justify-between cursor-pointer hover:bg-[#FFEDD5] transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-[10px] overflow-hidden bg-slate-200 shrink-0">
              <img
                src={propertyThumbnail}
                alt={propertyTitle}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-extrabold uppercase text-[#FF6B00] bg-white px-1.5 py-0.5 rounded-sm shadow-2xs">
                  Subject Property
                </span>
              </div>
              <p className="text-xs font-bold text-slate-900 truncate max-w-[220px] sm:max-w-md">
                {propertyTitle}
              </p>
            </div>
          </div>
          <span className="text-xs font-extrabold text-[#FF6B00]">
            PKR {propertyPrice.toLocaleString()}
          </span>
        </div>
      )}

      {/* 3. Messages Stream */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <div className="text-center my-2">
          <span className="px-3 py-1 rounded-full bg-slate-200/80 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
            Commercial In-App Protected Channel
          </span>
        </div>

        {displayMessages.map((msg: MessageModel) => {
          const isMe = msg.senderId === currentUser?.uid;
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-[85%] sm:max-w-[75%] ${
                isMe ? 'ml-auto' : 'mr-auto'
              }`}
            >
              <div
                className={`px-4 py-2.5 rounded-[18px] text-xs leading-relaxed font-medium shadow-2xs ${
                  isMe
                    ? 'bg-[#FF6B00] text-white rounded-tr-xs'
                    : 'bg-white text-slate-800 border border-slate-100 rounded-tl-xs'
                }`}
              >
                {msg.message || msg.text}
              </div>
              <div className="flex items-center gap-1 mt-1 px-1">
                <span className="text-[9px] text-slate-400 font-medium">
                  {msg.timestamp || 'Just now'}
                </span>
                {isMe && (
                  <CheckCheck className={`w-3 h-3 ${msg.seen ? 'text-[#FF6B00]' : 'text-slate-300'}`} />
                )}
              </div>
            </div>
          );
        })}

        {isTyping && (
          <div className="flex items-center gap-2 text-slate-400 text-xs italic">
            <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce" />
            <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce [animation-delay:0.2s]" />
            <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce [animation-delay:0.4s]" />
            <span className="text-[11px] font-semibold">{otherName} is typing...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Send error notification */}
      {sendError && (
        <div className="bg-rose-50 border-t border-rose-200 px-4 py-2 text-[11px] font-semibold text-rose-700 flex items-center justify-between">
          <span>{sendError}</span>
          <button
            type="button"
            onClick={() => setSendError(null)}
            className="text-rose-500 hover:text-rose-800 text-xs font-bold ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {/* 4. Chat Input Bar */}
      <form
        onSubmit={handleSend}
        className="bg-white border-t border-slate-200 p-3 flex items-center gap-2 safe-area-pb"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={`Message ${otherName}...`}
          className="flex-1 bg-slate-100/90 hover:bg-slate-100 focus:bg-white border border-transparent focus:border-[#FF6B00] rounded-full px-4 py-2.5 text-xs font-medium text-slate-900 placeholder-slate-400 outline-hidden transition-all"
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isSending}
          className="w-10 h-10 rounded-full bg-[#FF6B00] text-white flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#E55F00] active:scale-95 transition-all shadow-md shadow-[#FF6B00]/25 shrink-0"
        >
          <Send className="w-4 h-4 ml-0.5" />
        </button>
      </form>
    </div>
  );
};
