/**
 * RentMyShop Profile Screen
 * User info, commercial stats, Edit Profile, Change Password,
 * Dark Mode toggle, Notifications toggle, Admin Dashboard link, Delete Account.
 * Correctly displays the authenticated user's actual identity without default mock pictures.
 */
import React, { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useProperties } from '../context/PropertyContext';
import { useChat } from '../context/ChatContext';
import { useTheme } from '../context/ThemeContext';
import { ImageUploadService } from '../services/imageUploadService';
import { 
  User, 
  Mail, 
  Lock, 
  Trash2, 
  LogOut, 
  ChevronRight, 
  Edit3, 
  Shield, 
  Check, 
  CheckCircle2,
  AlertCircle,
  Building2,
  Heart,
  MessageSquare,
  Moon,
  Sun,
  Bell,
  Camera,
  User as UserIcon
} from 'lucide-react';

interface ProfileScreenProps {
  onNavigateToMyListings: () => void;
  onNavigateToFavorites: () => void;
  onNavigateToAdmin?: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  onNavigateToMyListings,
  onNavigateToFavorites,
  onNavigateToAdmin,
}) => {
  const { currentUser, updateUserProfile, changePassword, deleteAccount, logout } = useAuth();
  const { myListings, favorites } = useProperties();
  const { conversations } = useChat();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Modals state
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [showDeleteAccount, setShowDeleteAccount] = useState(false);

  // Edit profile state
  const [editName, setEditName] = useState(currentUser?.fullName || '');
  const [editImage, setEditImage] = useState(currentUser?.profileImage || '');
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);

  // Change password state
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passwordMsg, setPasswordMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Preferences toggles
  const { isDarkMode, toggleDarkMode } = useTheme();
  const [pushEnabled, setPushEnabled] = useState(true);

  // Handle Photo selection
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingPhoto(true);
    try {
      const url = await ImageUploadService.uploadImage(file);
      setEditImage(url);
    } catch {
      alert('Error updating photo.');
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateUserProfile({
      fullName: editName.trim(),
      profileImage: editImage,
    });
    setShowEditProfile(false);
  };

  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMsg(null);
    if (newPass.length < 6) {
      setPasswordMsg({ type: 'error', text: 'Password must be at least 6 characters.' });
      return;
    }
    if (newPass !== confirmPass) {
      setPasswordMsg({ type: 'error', text: 'New passwords do not match.' });
      return;
    }
    try {
      await changePassword(currentPass, newPass);
      setPasswordMsg({ type: 'success', text: 'Password updated successfully.' });
      setTimeout(() => {
        setShowChangePassword(false);
        setPasswordMsg(null);
        setCurrentPass('');
        setNewPass('');
        setConfirmPass('');
      }, 1500);
    } catch (err: any) {
      setPasswordMsg({ type: 'error', text: err.message || 'Error updating password.' });
    }
  };

  const handleDeleteAccountSubmit = async () => {
    try {
      await deleteAccount();
    } catch (err: any) {
      alert(err.message || 'Could not delete account.');
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-28 pt-4 px-4 max-w-2xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Header Profile Card */}
      <div className="bg-white rounded-[24px] p-6 border border-slate-100 shadow-xs flex flex-col sm:flex-row items-center gap-5">
        <div className="relative">
          <div className="w-20 h-20 rounded-full overflow-hidden ring-4 ring-[#FF6B00]/10 bg-slate-100 shadow-md flex items-center justify-center">
            {currentUser?.profileImage ? (
              <img
                src={currentUser.profileImage}
                alt={currentUser.fullName || 'User'}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center font-bold text-2xl">
                {currentUser?.fullName ? currentUser.fullName.charAt(0).toUpperCase() : <UserIcon className="w-8 h-8" />}
              </div>
            )}
          </div>
          <button
            onClick={() => {
              setEditName(currentUser?.fullName || '');
              setEditImage(currentUser?.profileImage || '');
              setShowEditProfile(true);
            }}
            className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-[#FF6B00] text-white flex items-center justify-center shadow-md ring-2 ring-white hover:bg-[#E55F00] transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="w-full text-center sm:text-left flex-1 min-w-0">
          <div className="flex items-center justify-center sm:justify-start gap-1.5 mb-1 max-w-full">
            <h2 className="text-lg font-extrabold text-slate-900 tracking-tight truncate" title={currentUser?.fullName || 'User'}>
              {currentUser?.fullName || 'User'}
            </h2>
            {Boolean(currentUser?.emailVerified) && (
              <span className="inline-flex items-center justify-center text-blue-500 shrink-0" title="Verified User">
                <CheckCircle2 className="w-4 h-4 fill-blue-500 text-white" />
              </span>
            )}
            {currentUser?.role === 'admin' && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-purple-100 text-purple-700 border border-purple-200 shrink-0">
                Admin
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 font-medium flex items-center justify-center sm:justify-start gap-1 truncate">
            <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="truncate">{currentUser?.email}</span>
          </p>
        </div>
      </div>

      {/* Commercial Stats Counters */}
      <div className="grid grid-cols-3 gap-3 text-center">
        <button
          onClick={onNavigateToMyListings}
          className="bg-white p-4 rounded-[20px] border border-slate-100 shadow-xs hover:border-[#FF6B00]/40 transition-all group"
        >
          <div className="w-8 h-8 rounded-full bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center mx-auto mb-1 group-hover:scale-110 transition-transform">
            <Building2 className="w-4 h-4" />
          </div>
          <span className="text-lg font-extrabold text-slate-900 block">{myListings.length}</span>
          <span className="text-[11px] font-semibold text-slate-500">My Listings</span>
        </button>

        <button
          onClick={onNavigateToFavorites}
          className="bg-white p-4 rounded-[20px] border border-slate-100 shadow-xs hover:border-rose-300 transition-all group"
        >
          <div className="w-8 h-8 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto mb-1 group-hover:scale-110 transition-transform">
            <Heart className="w-4 h-4" />
          </div>
          <span className="text-lg font-extrabold text-slate-900 block">{favorites.length}</span>
          <span className="text-[11px] font-semibold text-slate-500">Saved</span>
        </button>

        <div className="bg-white p-4 rounded-[20px] border border-slate-100 shadow-xs">
          <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center mx-auto mb-1">
            <MessageSquare className="w-4 h-4" />
          </div>
          <span className="text-lg font-extrabold text-slate-900 block">{conversations.length}</span>
          <span className="text-[11px] font-semibold text-slate-500">Inquiries</span>
        </div>
      </div>

      {/* Admin Panel Access Banner */}
      {currentUser?.role === 'admin' && onNavigateToAdmin && (
        <div 
          onClick={onNavigateToAdmin}
          className="p-4 rounded-[20px] bg-gradient-to-r from-purple-900 to-indigo-900 text-white flex items-center justify-between cursor-pointer shadow-lg shadow-purple-900/20 hover:opacity-95 transition-opacity"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
              <Shield className="w-5 h-5 text-purple-300" />
            </div>
            <div>
              <h3 className="text-sm font-bold">Admin Moderation Console</h3>
              <p className="text-[11px] text-purple-200">Moderate commercial spaces, users & reports</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-purple-300" />
        </div>
      )}

      {/* Settings & Preferences Group */}
      <div className="bg-white rounded-[24px] border border-slate-100 shadow-xs divide-y divide-slate-100 overflow-hidden">
        {/* Edit Profile */}
        <button
          onClick={() => {
            setEditName(currentUser?.fullName || '');
            setEditImage(currentUser?.profileImage || '');
            setShowEditProfile(true);
          }}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">
              <User className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-slate-800">Edit Profile</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Change Password */}
        <button
          onClick={() => setShowChangePassword(true)}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">
              <Lock className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-slate-800">Change Password</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Notifications Toggle */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 block">Push Notifications</span>
              <span className="text-[10px] text-slate-400">Receive alerts for tenant inquiries</span>
            </div>
          </div>
          <button
            onClick={() => setPushEnabled(!pushEnabled)}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              pushEnabled ? 'bg-[#FF6B00]' : 'bg-slate-200'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                pushEnabled ? 'right-1' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Dark Mode Toggle */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">
              {isDarkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 block">Dark Mode</span>
              <span className="text-[10px] text-slate-400">Reduce eye strain during night hours</span>
            </div>
          </div>
          <button
            onClick={toggleDarkMode}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              isDarkMode ? 'bg-[#FF6B00]' : 'bg-slate-200'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                isDarkMode ? 'right-1' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Sign Out */}
        <button
          onClick={logout}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-rose-50 flex items-center justify-center text-rose-600">
              <LogOut className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-rose-600">Sign Out</span>
          </div>
        </button>

        {/* Delete Account */}
        <button
          onClick={() => setShowDeleteAccount(true)}
          className="w-full p-4 flex items-center justify-between hover:bg-rose-50/50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
              <Trash2 className="w-4 h-4" />
            </div>
            <span className="text-xs font-semibold text-slate-400 hover:text-rose-600">Delete Account</span>
          </div>
        </button>
      </div>

      {/* MODAL 1: EDIT PROFILE */}
      {showEditProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-[24px] p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-base font-extrabold text-slate-900">Edit Commercial Profile</h3>
            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div className="flex flex-col items-center">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="relative group cursor-pointer w-20 h-20 rounded-full overflow-hidden ring-4 ring-[#FF6B00]/20 flex items-center justify-center bg-slate-100"
                >
                  {editImage ? (
                    <img
                      src={editImage}
                      alt="Preview"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-[#FFF5EE] text-[#FF6B00] flex items-center justify-center font-bold">
                      {editName ? editName.charAt(0).toUpperCase() : <UserIcon className="w-6 h-6" />}
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity">
                    <Camera className="w-5 h-5" />
                  </div>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
                <span className="text-[11px] font-semibold text-slate-400 mt-1">
                  {isUploadingPhoto ? 'Uploading photo...' : 'Click to update photo'}
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full p-3 rounded-[12px] bg-slate-50 border border-slate-200 text-xs font-semibold"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowEditProfile(false)}
                  className="px-4 py-2 rounded-[12px] bg-slate-100 text-slate-600 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-[12px] bg-[#FF6B00] text-white text-xs font-bold shadow-md hover:bg-[#E55F00]"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: CHANGE PASSWORD */}
      {showChangePassword && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-[24px] p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-base font-extrabold text-slate-900">Change Password</h3>
            {passwordMsg && (
              <div
                className={`p-3 rounded-[12px] text-xs font-semibold flex items-center gap-2 ${
                  passwordMsg.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border border-rose-200'
                }`}
              >
                {passwordMsg.type === 'success' ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                <span>{passwordMsg.text}</span>
              </div>
            )}
            <form onSubmit={handleChangePasswordSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Current Password</label>
                <input
                  type="password"
                  required
                  value={currentPass}
                  onChange={(e) => setCurrentPass(e.target.value)}
                  placeholder="••••••••"
                  className="w-full p-2.5 rounded-[12px] bg-slate-50 border border-slate-200 text-xs font-semibold"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">New Password</label>
                <input
                  type="password"
                  required
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  placeholder="Min 6 characters"
                  className="w-full p-2.5 rounded-[12px] bg-slate-50 border border-slate-200 text-xs font-semibold"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Confirm New Password</label>
                <input
                  type="password"
                  required
                  value={confirmPass}
                  onChange={(e) => setConfirmPass(e.target.value)}
                  placeholder="Re-enter new password"
                  className="w-full p-2.5 rounded-[12px] bg-slate-50 border border-slate-200 text-xs font-semibold"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowChangePassword(false)}
                  className="px-4 py-2 rounded-[12px] bg-slate-100 text-slate-600 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-[12px] bg-[#FF6B00] text-white text-xs font-bold shadow-md hover:bg-[#E55F00]"
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: DELETE ACCOUNT */}
      {showDeleteAccount && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-[24px] p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center gap-2 text-rose-600">
              <Trash2 className="w-5 h-5" />
              <h3 className="text-base font-extrabold text-slate-900">Delete Account</h3>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Are you sure you want to permanently delete your RentMyShop account? This will remove all your commercial listings, message history, and saved properties. This action cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteAccount(false)}
                className="px-4 py-2 rounded-[12px] bg-slate-100 text-slate-600 text-xs font-bold"
              >
                Keep Account
              </button>
              <button
                type="button"
                onClick={handleDeleteAccountSubmit}
                className="px-5 py-2 rounded-[12px] bg-rose-600 text-white text-xs font-bold shadow-md hover:bg-rose-700"
              >
                Permanently Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
