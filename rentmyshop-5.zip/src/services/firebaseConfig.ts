/**
 * RentMyShop Firebase Configuration & Service Bootstrap
 * Supports environment variables added via .env (VITE_FIREBASE_API_KEY, etc.)
 */
import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore';

// Environment variables from client Vite with production fallback
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyAacFV0yD0jPrH5DUw8lhS86JCNkVeyn7I",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "rentmyshop-ed18a.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "rentmyshop-ed18a",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "rentmyshop-ed18a.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "68604637711",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:68604637711:web:b7d6c67aeb88d7e25ee97a",
};

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

export const isFirebaseConfigured = (): boolean => {
  return Boolean(
    firebaseConfig.apiKey &&
    firebaseConfig.projectId &&
    firebaseConfig.apiKey.length > 5 &&
    !firebaseConfig.apiKey.includes('MY_')
  );
};

export const initFirebase = () => {
  if (isFirebaseConfigured()) {
    try {
      if (!getApps().length) {
        app = initializeApp(firebaseConfig);
      } else {
        app = getApps()[0];
      }
      auth = getAuth(app);
      db = getFirestore(app);
    } catch (err) {
      console.warn('[RentMyShop] Firebase init warning:', err);
    }
  }
  return { app, auth, db };
};

// Initialize on module load safely
const instances = initFirebase();
export const firebaseAppInstance = instances.app;
export const firebaseAuthInstance = instances.auth;
export const firestoreInstance = instances.db;

/**
 * RentMyShop Production-Grade Firestore Security Rules
 * Prepared for Firebase deployment
 */
export const FIRESTORE_RULES = `
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }

    function isOwner(userId) {
      return isAuthenticated() && request.auth.uid == userId;
    }

    function isEmailVerified() {
      return isAuthenticated() && 
        (request.auth.token.email_verified == true || 
         request.auth.token.firebase.sign_in_provider == 'google.com');
    }

    function isAdmin() {
      return isAuthenticated() && 
        (request.auth.token.role == 'admin' || 
         (exists(/databases/$(database)/documents/users/$(request.auth.uid)) && 
          get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin'));
    }

    // 1. Users / Profiles Collection
    match /users/{userId} {
      allow read: if isAuthenticated();
      allow create: if isOwner(userId) && request.resource.data.uid == userId;
      allow update: if isOwner(userId) && 
        (!request.resource.data.diff(resource.data).affectedKeys().hasAny(['role', 'uid', 'createdAt']) || isAdmin());
      allow delete: if isOwner(userId) || isAdmin();
    }

    // 2. Commercial Property Listings (shops)
    match /shops/{shopId} {
      allow read: if resource.data.isDeleted == false || 
        (isAuthenticated() && (resource.data.ownerId == request.auth.uid || isAdmin()));

      allow create: if isEmailVerified() && 
        request.resource.data.ownerId == request.auth.uid && 
        request.resource.data.isDeleted == false;

      allow update: if (
        (isAuthenticated() && (resource.data.ownerId == request.auth.uid || isAdmin()) &&
         !request.resource.data.diff(resource.data).affectedKeys().hasAny(['ownerId', 'createdAt']) &&
         (!request.resource.data.diff(resource.data).affectedKeys().hasAny(['isFeatured']) || isAdmin()))
        ||
        (request.resource.data.diff(resource.data).affectedKeys().hasOnly(['views']))
        ||
        (isAuthenticated() && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['favorites']))
        ||
        (isAuthenticated() && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['chatCount']))
      );

      allow delete: if isAuthenticated() && (resource.data.ownerId == request.auth.uid || isAdmin());
    }

    // 3. User Favorites Collection (Doc ID: userId_shopId)
    match /favorites/{favoriteId} {
      allow read: if isAuthenticated() && resource.data.userId == request.auth.uid;
      allow create: if isAuthenticated() && request.resource.data.userId == request.auth.uid;
      allow delete: if isAuthenticated() && resource.data.userId == request.auth.uid;
      allow update: if false;
    }

    // 4. Conversations Collection (Participant-scoped)
    match /conversations/{conversationId} {
      allow read: if isAuthenticated() && 
        (resource == null || 
         !('participants' in resource.data) || 
         request.auth.uid in resource.data.participants);

      allow create: if isEmailVerified() && 
        (request.resource == null ||
         !('participants' in request.resource.data) ||
         request.auth.uid in request.resource.data.participants);

      allow update: if isAuthenticated() && 
        ((request.resource != null && 'participants' in request.resource.data && request.auth.uid in request.resource.data.participants) ||
         (resource != null && 'participants' in resource.data && request.auth.uid in resource.data.participants) ||
         (resource != null && !('participants' in resource.data)));

      allow delete: if isAuthenticated() && 
        (resource == null || !('participants' in resource.data) || request.auth.uid in resource.data.participants);
    }

    // 5. Messages Collection (Sender-scoped & Participant-only)
    match /messages/{messageId} {
      allow read: if isAuthenticated() && 
        (resource == null ||
         resource.data.senderId == request.auth.uid || 
         resource.data.receiverId == request.auth.uid ||
         ('participants' in resource.data && request.auth.uid in resource.data.participants));

      allow create: if isEmailVerified() && 
        request.resource.data.senderId == request.auth.uid;

      allow update: if isAuthenticated() && 
        (resource.data.senderId == request.auth.uid || 
         (resource.data.receiverId == request.auth.uid && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['isSeen'])));

      allow delete: if isAuthenticated() && 
        (resource.data.senderId == request.auth.uid);
    }

    // 6. Notifications Collection
    match /notifications/{notificationId} {
      allow read: if isAuthenticated() && 
        (resource.data.receiverId == request.auth.uid || resource.data.receiverId == 'all');

      allow create: if isAuthenticated();

      allow update: if isAuthenticated() && 
        (resource.data.receiverId == request.auth.uid || resource.data.receiverId == 'all') &&
        request.resource.data.diff(resource.data).affectedKeys().hasOnly(['isRead']);

      allow delete: if isAuthenticated() && 
        resource.data.receiverId == request.auth.uid;
    }

    // 7. Reports Collection (Moderation)
    match /reports/{reportId} {
      allow create: if isAuthenticated() && 
        request.resource.data.reporterId == request.auth.uid;

      allow read, update, delete: if isAdmin();
    }

    // 8. Categories Collection (Read-only catalog for clients)
    match /categories/{categoryId} {
      allow read: if true;
      allow write: if isAdmin();
    }

    // 9. Default Deny for any unmapped paths
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
`;
