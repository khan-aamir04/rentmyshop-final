/**
 * RentMyShop Location & Geolocation Service for Pakistan
 * Complete city coverage across all provinces and territories,
 * location alias matching (e.g., Nawabshah <-> Shaheed Benazirabad),
 * normalization, coordinate resolution, and Google Maps deep-links.
 */

export interface LocationCoordinates {
  latitude: number;
  longitude: number;
  city?: string;
  address?: string;
}

export interface PakistanCity {
  city: string;
  province: string;
  lat: number;
  lng: number;
  aliases?: string[];
}

/**
 * Comprehensive dataset of cities across all provinces and territories in Pakistan:
 * - Sindh
 * - Punjab
 * - Khyber Pakhtunkhwa (KP)
 * - Balochistan
 * - Islamabad Capital Territory (ICT)
 * - Gilgit-Baltistan (GB)
 * - Azad Jammu and Kashmir (AJK)
 */
export const PAKISTAN_CITIES: PakistanCity[] = [
  // --- Sindh ---
  { city: 'Karachi', province: 'Sindh', lat: 24.8607, lng: 67.0011, aliases: ['khi'] },
  { city: 'Hyderabad', province: 'Sindh', lat: 25.3960, lng: 68.3578, aliases: ['hyd'] },
  { city: 'Nawabshah', province: 'Sindh', lat: 26.2483, lng: 68.4096, aliases: ['shaheed benazirabad', 'shaheed benazir abad', 'sba'] },
  { city: 'Sukkur', province: 'Sindh', lat: 27.7052, lng: 68.8574, aliases: ['skr'] },
  { city: 'Larkana', province: 'Sindh', lat: 27.5590, lng: 68.2120, aliases: ['lrk'] },
  { city: 'Mirpur Khas', province: 'Sindh', lat: 25.5276, lng: 69.0159 },
  { city: 'Shikarpur', province: 'Sindh', lat: 27.9570, lng: 68.6378 },
  { city: 'Jacobabad', province: 'Sindh', lat: 28.2810, lng: 68.4376 },
  { city: 'Khairpur', province: 'Sindh', lat: 27.5295, lng: 68.7592 },
  { city: 'Dadu', province: 'Sindh', lat: 26.7329, lng: 67.7763 },
  { city: 'Tando Adam', province: 'Sindh', lat: 25.7682, lng: 68.6622, aliases: ['tando adam khan'] },
  { city: 'Tando Allahyar', province: 'Sindh', lat: 25.4605, lng: 68.7170 },
  { city: 'Thatta', province: 'Sindh', lat: 24.7475, lng: 67.9235 },
  { city: 'Badin', province: 'Sindh', lat: 24.6560, lng: 68.8370 },
  { city: 'Ghotki', province: 'Sindh', lat: 28.0060, lng: 69.3161 },
  { city: 'Kotri', province: 'Sindh', lat: 25.3670, lng: 68.3120 },
  { city: 'Umerkot', province: 'Sindh', lat: 25.3549, lng: 69.7376 },
  { city: 'Kandhkot', province: 'Sindh', lat: 28.2439, lng: 69.1824 },
  { city: 'Kashmore', province: 'Sindh', lat: 28.4332, lng: 69.5836 },
  { city: 'Shahdadkot', province: 'Sindh', lat: 27.8474, lng: 67.9069 },
  { city: 'Rohri', province: 'Sindh', lat: 27.6744, lng: 68.8957 },
  { city: 'Moro', province: 'Sindh', lat: 26.6632, lng: 68.0003 },
  { city: 'Sehwan', province: 'Sindh', lat: 26.4258, lng: 67.8614, aliases: ['sehwan sharif'] },

  // --- Punjab ---
  { city: 'Lahore', province: 'Punjab', lat: 31.5204, lng: 74.3587, aliases: ['lhr'] },
  { city: 'Faisalabad', province: 'Punjab', lat: 31.4504, lng: 73.1350, aliases: ['fsd', 'lyallpur'] },
  { city: 'Rawalpindi', province: 'Punjab', lat: 33.5651, lng: 73.0169, aliases: ['pindi', 'rwp'] },
  { city: 'Multan', province: 'Punjab', lat: 30.1575, lng: 71.5249, aliases: ['mux'] },
  { city: 'Gujranwala', province: 'Punjab', lat: 32.1877, lng: 74.1945 },
  { city: 'Sialkot', province: 'Punjab', lat: 32.4945, lng: 74.5229, aliases: ['skt'] },
  { city: 'Bahawalpur', province: 'Punjab', lat: 29.3544, lng: 71.6911 },
  { city: 'Sargodha', province: 'Punjab', lat: 32.0836, lng: 72.6711 },
  { city: 'Sahiwal', province: 'Punjab', lat: 30.6682, lng: 73.1114, aliases: ['montgomery'] },
  { city: 'Sheikhupura', province: 'Punjab', lat: 31.7131, lng: 73.9783 },
  { city: 'Rahim Yar Khan', province: 'Punjab', lat: 28.4195, lng: 70.3024, aliases: ['ryk', 'r.y. khan'] },
  { city: 'Jhang', province: 'Punjab', lat: 31.2781, lng: 72.3317 },
  { city: 'Gujrat', province: 'Punjab', lat: 32.5742, lng: 74.0754 },
  { city: 'Kasur', province: 'Punjab', lat: 31.1179, lng: 74.4461 },
  { city: 'Dera Ghazi Khan', province: 'Punjab', lat: 30.0489, lng: 70.6455, aliases: ['dg khan', 'd.g. khan', 'dgkhan'] },
  { city: 'Okara', province: 'Punjab', lat: 30.8081, lng: 73.4458 },
  { city: 'Chiniot', province: 'Punjab', lat: 31.7200, lng: 72.9789 },
  { city: 'Kamoke', province: 'Punjab', lat: 31.9744, lng: 74.2244 },
  { city: 'Hafizabad', province: 'Punjab', lat: 32.0679, lng: 73.6872 },
  { city: 'Mandi Bahauddin', province: 'Punjab', lat: 32.5870, lng: 73.4912, aliases: ['mbdin'] },
  { city: 'Jhelum', province: 'Punjab', lat: 32.9425, lng: 73.7257 },
  { city: 'Khanewal', province: 'Punjab', lat: 30.3017, lng: 71.9321 },
  { city: 'Muzaffargarh', province: 'Punjab', lat: 30.0726, lng: 71.1938 },
  { city: 'Murree', province: 'Punjab', lat: 33.9070, lng: 73.3943 },
  { city: 'Wah Cantt', province: 'Punjab', lat: 33.7715, lng: 72.7511, aliases: ['wah'] },
  { city: 'Taxila', province: 'Punjab', lat: 33.7463, lng: 72.8397 },
  { city: 'Chakwal', province: 'Punjab', lat: 32.9328, lng: 72.8630 },
  { city: 'Vehari', province: 'Punjab', lat: 30.0419, lng: 72.3489 },
  { city: 'Mianwali', province: 'Punjab', lat: 32.5853, lng: 71.5436 },
  { city: 'Bahawalnagar', province: 'Punjab', lat: 29.9987, lng: 73.2536 },
  { city: 'Burewala', province: 'Punjab', lat: 30.1585, lng: 72.6817 },
  { city: 'Pakpattan', province: 'Punjab', lat: 30.3410, lng: 73.3866 },
  { city: 'Gojra', province: 'Punjab', lat: 31.1492, lng: 72.6842 },
  { city: 'Attock', province: 'Punjab', lat: 33.7660, lng: 72.3609, aliases: ['campbellpur'] },
  { city: 'Kot Addu', province: 'Punjab', lat: 30.4700, lng: 70.9644 },
  { city: 'Lodhran', province: 'Punjab', lat: 29.5405, lng: 71.6336 },
  { city: 'Layyah', province: 'Punjab', lat: 30.9613, lng: 70.9428 },
  { city: 'Wazirabad', province: 'Punjab', lat: 32.4430, lng: 74.1197 },
  { city: 'Chunian', province: 'Punjab', lat: 30.9639, lng: 73.9803 },

  // --- Khyber Pakhtunkhwa ---
  { city: 'Peshawar', province: 'Khyber Pakhtunkhwa', lat: 34.0151, lng: 71.5249, aliases: ['pew'] },
  { city: 'Mardan', province: 'Khyber Pakhtunkhwa', lat: 34.1986, lng: 72.0404 },
  { city: 'Mingora', province: 'Khyber Pakhtunkhwa', lat: 34.7717, lng: 72.3602, aliases: ['swat'] },
  { city: 'Abbottabad', province: 'Khyber Pakhtunkhwa', lat: 34.1688, lng: 73.2215 },
  { city: 'Kohat', province: 'Khyber Pakhtunkhwa', lat: 33.5869, lng: 71.4414 },
  { city: 'Dera Ismail Khan', province: 'Khyber Pakhtunkhwa', lat: 31.8314, lng: 70.9017, aliases: ['di khan', 'd.i. khan', 'dikhan'] },
  { city: 'Haripur', province: 'Khyber Pakhtunkhwa', lat: 33.9999, lng: 72.9341 },
  { city: 'Bannu', province: 'Khyber Pakhtunkhwa', lat: 32.9861, lng: 70.6042 },
  { city: 'Mansehra', province: 'Khyber Pakhtunkhwa', lat: 34.3302, lng: 73.1968 },
  { city: 'Swabi', province: 'Khyber Pakhtunkhwa', lat: 34.1202, lng: 72.4698 },
  { city: 'Charsadda', province: 'Khyber Pakhtunkhwa', lat: 34.1482, lng: 71.7406 },
  { city: 'Nowshera', province: 'Khyber Pakhtunkhwa', lat: 34.0153, lng: 71.9747 },
  { city: 'Batkhela', province: 'Khyber Pakhtunkhwa', lat: 34.6171, lng: 71.9723 },
  { city: 'Timergara', province: 'Khyber Pakhtunkhwa', lat: 34.8281, lng: 71.8407 },
  { city: 'Karak', province: 'Khyber Pakhtunkhwa', lat: 33.1118, lng: 71.0924 },
  { city: 'Hangu', province: 'Khyber Pakhtunkhwa', lat: 33.5281, lng: 71.0571 },
  { city: 'Chitral', province: 'Khyber Pakhtunkhwa', lat: 35.8510, lng: 71.7864 },
  { city: 'Dir', province: 'Khyber Pakhtunkhwa', lat: 35.2074, lng: 71.8743 },

  // --- Balochistan ---
  { city: 'Quetta', province: 'Balochistan', lat: 30.1798, lng: 66.9750, aliases: ['qta'] },
  { city: 'Gwadar', province: 'Balochistan', lat: 25.1216, lng: 62.3254 },
  { city: 'Turbat', province: 'Balochistan', lat: 26.0031, lng: 63.0544 },
  { city: 'Khuzdar', province: 'Balochistan', lat: 27.8119, lng: 66.6177 },
  { city: 'Hub', province: 'Balochistan', lat: 25.0298, lng: 66.8837, aliases: ['hub chowki'] },
  { city: 'Chaman', province: 'Balochistan', lat: 30.9236, lng: 66.4512 },
  { city: 'Sibi', province: 'Balochistan', lat: 29.5448, lng: 67.8764 },
  { city: 'Zhob', province: 'Balochistan', lat: 31.3417, lng: 69.4486 },
  { city: 'Loralai', province: 'Balochistan', lat: 30.3705, lng: 68.5979 },
  { city: 'Dera Murad Jamali', province: 'Balochistan', lat: 28.5466, lng: 68.2231 },
  { city: 'Nasirabad', province: 'Balochistan', lat: 28.5833, lng: 68.1667 },
  { city: 'Pishin', province: 'Balochistan', lat: 30.5803, lng: 66.9961 },
  { city: 'Kalat', province: 'Balochistan', lat: 29.0222, lng: 66.5916 },
  { city: 'Mastung', province: 'Balochistan', lat: 29.7997, lng: 66.8455 },

  // --- Islamabad Capital Territory ---
  { city: 'Islamabad', province: 'Islamabad Capital Territory', lat: 33.6844, lng: 73.0479, aliases: ['isb'] },

  // --- Gilgit-Baltistan ---
  { city: 'Gilgit', province: 'Gilgit-Baltistan', lat: 35.9208, lng: 74.3144 },
  { city: 'Skardu', province: 'Gilgit-Baltistan', lat: 35.2971, lng: 75.6333 },
  { city: 'Hunza', province: 'Gilgit-Baltistan', lat: 36.3167, lng: 74.6500, aliases: ['karimabad', 'aliabad'] },
  { city: 'Chilas', province: 'Gilgit-Baltistan', lat: 35.4129, lng: 74.0961 },
  { city: 'Ghizer', province: 'Gilgit-Baltistan', lat: 36.1667, lng: 73.6667 },
  { city: 'Diamer', province: 'Gilgit-Baltistan', lat: 35.4333, lng: 74.1000 },
  { city: 'Astore', province: 'Gilgit-Baltistan', lat: 35.3667, lng: 74.8500 },
  { city: 'Nagar', province: 'Gilgit-Baltistan', lat: 36.2500, lng: 74.6500 },
  { city: 'Khaplu', province: 'Gilgit-Baltistan', lat: 35.1500, lng: 76.3333 },

  // --- Azad Jammu and Kashmir ---
  { city: 'Muzaffarabad', province: 'Azad Jammu and Kashmir', lat: 34.3700, lng: 73.4711 },
  { city: 'Mirpur', province: 'Azad Jammu and Kashmir', lat: 33.1484, lng: 73.7519, aliases: ['mirpur ajk'] },
  { city: 'Rawalakot', province: 'Azad Jammu and Kashmir', lat: 33.8578, lng: 73.7604 },
  { city: 'Kotli', province: 'Azad Jammu and Kashmir', lat: 33.5156, lng: 73.9019 },
  { city: 'Bhimber', province: 'Azad Jammu and Kashmir', lat: 32.9747, lng: 74.0786 },
  { city: 'Bagh', province: 'Azad Jammu and Kashmir', lat: 33.9800, lng: 73.7744 },
  { city: 'Pallandri', province: 'Azad Jammu and Kashmir', lat: 33.7128, lng: 73.6886 },
];

/**
 * Common commercial city aliases & spelling variations dictionary
 */
export const CITY_ALIASES: Record<string, string[]> = {
  'nawabshah': ['shaheed benazirabad', 'shaheed benazir abad', 'sba'],
  'shaheed benazirabad': ['nawabshah', 'shaheed benazir abad', 'sba'],
  'shaheed benazir abad': ['nawabshah', 'shaheed benazirabad', 'sba'],
  'karachi': ['khi'],
  'lahore': ['lhr'],
  'islamabad': ['isb'],
  'rawalpindi': ['pindi', 'rwp'],
  'peshawar': ['pew'],
  'faisalabad': ['fsd', 'lyallpur'],
  'sialkot': ['skt'],
  'mingora': ['swat'],
  'swat': ['mingora'],
  'dera ghazi khan': ['dg khan', 'd.g. khan', 'dgkhan'],
  'dg khan': ['dera ghazi khan', 'd.g. khan'],
  'dera ismail khan': ['di khan', 'd.i. khan', 'dikhan'],
  'di khan': ['dera ismail khan', 'd.i. khan'],
  'rahim yar khan': ['ryk', 'r.y. khan'],
  'wah cantt': ['wah'],
  'tando adam': ['tando adam khan'],
  'hub': ['hub chowki'],
  'sehwan': ['sehwan sharif'],
  'mirpur': ['mirpur ajk'],
  'multan': ['mux'],
  'sukkur': ['skr'],
  'larkana': ['lrk'],
  'hyderabad': ['hyd'],
};

/**
 * Normalize whitespace and case when matching city names
 */
export function normalizeCityName(cityName?: string | null): string {
  if (!cityName) return '';
  return cityName
    .trim()
    .toLowerCase()
    .replace(/[.,\-_/]/g, ' ')
    .replace(/\s+/g, ' ');
}

export function getProvinceForCity(cityName?: string | null): string {
  if (!cityName) return '';
  const norm = normalizeCityName(cityName);
  const found = PAKISTAN_CITIES.find(
    (c) => normalizeCityName(c.city) === norm || (c.aliases && c.aliases.some((a) => normalizeCityName(a) === norm))
  );
  return found?.province || '';
}

/**
 * Check if a listing's city matches the filtered city, supporting exact match,
 * substrings, documented city aliases (e.g. Nawabshah & Shaheed Benazirabad),
 * and province-level filtering.
 */
export function matchesCity(
  listingCity?: string | null,
  filterCity?: string | null
): boolean {
  if (!filterCity || filterCity === 'all' || filterCity === 'All Cities') {
    return true;
  }
  if (!listingCity) return false;

  const normListing = normalizeCityName(listingCity);
  const normFilter = normalizeCityName(filterCity);

  if (normListing === normFilter) return true;
  if (normListing.includes(normFilter) || normFilter.includes(normListing)) return true;

  // Check aliases from filter
  const filterAliases = CITY_ALIASES[normFilter] || [];
  if (filterAliases.some((alias) => normListing === alias || normListing.includes(alias))) {
    return true;
  }

  // Check aliases from listing
  const listingAliases = CITY_ALIASES[normListing] || [];
  if (listingAliases.some((alias) => normFilter === alias || normFilter.includes(alias))) {
    return true;
  }

  // Check province matching
  const cityData = PAKISTAN_CITIES.find(
    (c) => normalizeCityName(c.city) === normListing || (c.aliases && c.aliases.some((a) => normalizeCityName(a) === normListing))
  );
  if (cityData) {
    const normProv = normalizeCityName(cityData.province);
    if (normProv === normFilter || normProv.includes(normFilter) || normFilter.includes(normProv)) {
      return true;
    }
  }

  return false;
}

/**
 * Match a city in free-text search queries (including city aliases and province)
 */
export function matchCitySearch(
  listingCity?: string | null,
  searchQuery?: string | null
): boolean {
  if (!listingCity || !searchQuery) return false;
  const normCity = normalizeCityName(listingCity);
  const q = normalizeCityName(searchQuery);
  if (!q) return false;

  if (normCity.includes(q) || q.includes(normCity)) return true;

  // Check aliases
  const aliases = CITY_ALIASES[normCity] || [];
  if (aliases.some((alias) => alias.includes(q) || q.includes(alias))) return true;

  // Check province
  const cityData = PAKISTAN_CITIES.find(
    (c) => normalizeCityName(c.city) === normCity || (c.aliases && c.aliases.some((a) => normalizeCityName(a) === normCity))
  );
  if (cityData) {
    const normProv = normalizeCityName(cityData.province);
    if (normProv.includes(q) || q.includes(normProv)) return true;
  }

  return false;
}

/**
 * Finds latitude and longitude for a city name, defaulting to Karachi if unknown
 */
export function getCityCoordinates(cityName: string): { lat: number; lng: number } {
  const norm = normalizeCityName(cityName);
  const found = PAKISTAN_CITIES.find((c) => {
    if (normalizeCityName(c.city) === norm) return true;
    if (c.aliases?.some((a) => normalizeCityName(a) === norm)) return true;
    return false;
  });

  if (found) {
    return { lat: found.lat, lng: found.lng };
  }
  // Default commercial hub: Karachi
  return { lat: 24.8607, lng: 67.0011 };
}

/**
 * Popular commercial cities for quick selectors
 */
export const POPULAR_COMMERCIAL_CITIES = [
  { city: 'Karachi', state: 'Sindh', lat: 24.8607, lng: 67.0011 },
  { city: 'Lahore', state: 'Punjab', lat: 31.5204, lng: 74.3587 },
  { city: 'Islamabad', state: 'ICT', lat: 33.6844, lng: 73.0479 },
  { city: 'Rawalpindi', state: 'Punjab', lat: 33.5651, lng: 73.0169 },
  { city: 'Faisalabad', state: 'Punjab', lat: 31.4504, lng: 73.1350 },
  { city: 'Multan', state: 'Punjab', lat: 30.1575, lng: 71.5249 },
  { city: 'Peshawar', state: 'KP', lat: 34.0151, lng: 71.5249 },
  { city: 'Quetta', state: 'Balochistan', lat: 30.1798, lng: 66.9750 },
  { city: 'Nawabshah', state: 'Sindh', lat: 26.2483, lng: 68.4096 },
  { city: 'Hyderabad', state: 'Sindh', lat: 25.3960, lng: 68.3578 },
  { city: 'Sukkur', state: 'Sindh', lat: 27.7052, lng: 68.8574 },
  { city: 'Gilgit', state: 'GB', lat: 35.9208, lng: 74.3144 },
];

export class LocationService {
  /**
   * Requests device GPS coordinates with permission handling and Pakistan reverse geocode fallback
   */
  public static async getCurrentLocation(): Promise<LocationCoordinates> {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve({
          latitude: 24.8607,
          longitude: 67.0011,
          city: 'Karachi',
          address: 'I.I. Chundrigar Road, Karachi',
        });
        return;
      }
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          let city = 'Karachi';
          let address = `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
          try {
            const res = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=14&addressdetails=1`,
              { headers: { 'Accept-Language': 'en' } }
            );
            if (res.ok) {
              const data = await res.json();
              if (data.address) {
                const detected = data.address.city || data.address.town || data.address.suburb || data.address.county;
                if (detected) {
                  city = detected;
                }
                address = data.display_name?.split(',').slice(0, 3).join(',') || address;
              }
            }
          } catch {
            // Keep default
          }
          resolve({
            latitude: lat,
            longitude: lng,
            city,
            address,
          });
        },
        (error) => {
          console.warn('[RentMyShop] Geolocation error:', error.message);
          resolve({
            latitude: 24.8607,
            longitude: 67.0011,
            city: 'Karachi',
            address: 'I.I. Chundrigar Road, Karachi',
          });
        },
        { timeout: 8000, enableHighAccuracy: true }
      );
    });
  }

  /**
   * Validates that coordinates are numeric and within valid geographic bounds
   */
  public static isValidCoordinates(latitude?: number | null, longitude?: number | null): boolean {
    if (typeof latitude !== 'number' || typeof longitude !== 'number') return false;
    if (isNaN(latitude) || isNaN(longitude)) return false;
    return latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180;
  }

  /**
   * Generates Google Maps coordinates-based search link using exact saved latitude and longitude:
   * https://www.google.com/maps/search/?api=1&query=LATITUDE%2CLONGITUDE
   */
  public static getGoogleMapsUrl(latitude?: number | null, longitude?: number | null, _legacyTitle?: string): string {
    if (!LocationService.isValidCoordinates(latitude, longitude)) {
      return '';
    }
    const lat = Number(latitude);
    const lng = Number(longitude);
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${lat},${lng}`)}`;
  }

  /**
   * Calculates distance between two coordinates in kilometers
   */
  public static calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Earth radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Number((R * c).toFixed(1));
  }
}
